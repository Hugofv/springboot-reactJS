export interface Sistema {
  id: Int16Array;
  descricao: string;
  sigla: string;
  email: string;
  url: string;
}
