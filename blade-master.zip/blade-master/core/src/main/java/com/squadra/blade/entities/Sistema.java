package com.squadra.blade.entities;

import javax.persistence.*;

@Entity
@Table(name = "Sistema")
public class Sistema {

    @Id
    @GeneratedValue
    private long id;
    private String descricao;
    private String sigla;
    private String email;
    private String url;
    @Column(columnDefinition = "boolean default true", nullable = false)
    private boolean ativo;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
}
