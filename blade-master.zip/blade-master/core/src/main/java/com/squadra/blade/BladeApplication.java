package com.squadra.blade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BladeApplication {

    public static void main(String[] args) {
        SpringApplication.run(BladeApplication.class, args);
    }
}
