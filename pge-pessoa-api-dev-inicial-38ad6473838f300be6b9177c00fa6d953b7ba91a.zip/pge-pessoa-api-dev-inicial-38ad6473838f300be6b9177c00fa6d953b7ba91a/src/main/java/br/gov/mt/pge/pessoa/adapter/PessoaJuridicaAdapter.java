/*
 * PessoaJuridicaAdapter.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.adapter;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.gov.mt.pge.comum.util.Util;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.domain.PessoaJuridica;
import br.gov.mt.pge.pessoa.service.PessoaJuridicaService;
import br.gov.mt.pge.pessoa.to.EmailTO;
import br.gov.mt.pge.pessoa.to.EnderecoTO;
import br.gov.mt.pge.pessoa.to.PessoaJuridicaTO;
import br.gov.mt.pge.pessoa.to.TelefoneTO;

/**
 * Classe adapter referente a entidade {@link PessoaJuridica}.
 * 
 * @author Squadra Tecnologia
 */
@Component
public class PessoaJuridicaAdapter extends PessoaAdapter {

	@Autowired
	private PessoaJuridicaService pessoaJuridicaService;

	/**
	 * Retorna a instância de {@link PessoaJuridica} conforme a instância de
	 * {@link PessoaJuridicaTO}.
	 * 
	 * @param pessoaJuridicaTO
	 * @return
	 */
	public PessoaJuridica getPessoaJuridica(PessoaJuridicaTO pessoaJuridicaTO) {

		Pessoa pessoa = new Pessoa();
		PessoaJuridica pessoaJuridica = new PessoaJuridica();

		if (pessoaJuridicaTO.getId() != null) {
			pessoaJuridica = pessoaJuridicaService.getPessoaJuridicaByIdPessoa(pessoaJuridicaTO.getId());
			pessoa = pessoaJuridica.getPessoa();
		}

		addOrRemoveEmails(pessoa, pessoaJuridicaTO.getEmails());
		addOrRemoveTelefones(pessoa, pessoaJuridicaTO.getTelefones());
		addOrRemoveEnderecos(pessoa, pessoaJuridicaTO.getEnderecos());

		// PessoaJuridica
		pessoaJuridica.setPessoa(pessoa);
		pessoa.setNome(pessoaJuridicaTO.getNome());
		pessoaJuridica.setNomeFantasia(pessoaJuridicaTO.getNomeFantasia());

		String cnpj = Util.removerCaracteresNaoNumericos(pessoaJuridicaTO.getCnpj());
		pessoaJuridica.setCnpj(cnpj);

		String ie = Util.removerCaracteresNaoNumericos(pessoaJuridicaTO.getIe());
		pessoaJuridica.setIe(ie);

		return pessoaJuridica;
	}

	/**
	 * Retorna a instância de {@link PessoaJuridicaTO} conforme a instância de
	 * {@link PessoaJuridica}.
	 * 
	 * @param pessoaFisica
	 * @return
	 */
	public PessoaJuridicaTO getPessoaJuridicaTO(final PessoaJuridica pessoaJuridica) {
		PessoaJuridicaTO pessoaJuridicaTO = new PessoaJuridicaTO();
		pessoaJuridicaTO.setNomeFantasia(pessoaJuridica.getNomeFantasia());
		pessoaJuridicaTO.setNome(pessoaJuridica.getPessoa().getNome());
		pessoaJuridicaTO.setId(pessoaJuridica.getPessoa().getId());
		pessoaJuridicaTO.setCnpj(pessoaJuridica.getCnpj());
		pessoaJuridicaTO.setIe(pessoaJuridica.getIe());

		List<EmailTO> emailsTO = getEmailsTO(pessoaJuridica.getPessoa());
		pessoaJuridicaTO.setEmails(emailsTO);

		List<TelefoneTO> telefonesTO = getTelefonesTO(pessoaJuridica.getPessoa());
		pessoaJuridicaTO.setTelefones(telefonesTO);

		List<EnderecoTO> enderecosTO = getEnderecosTO(pessoaJuridica.getPessoa());
		pessoaJuridicaTO.setEnderecos(enderecosTO);

		return pessoaJuridicaTO;
	}
}
