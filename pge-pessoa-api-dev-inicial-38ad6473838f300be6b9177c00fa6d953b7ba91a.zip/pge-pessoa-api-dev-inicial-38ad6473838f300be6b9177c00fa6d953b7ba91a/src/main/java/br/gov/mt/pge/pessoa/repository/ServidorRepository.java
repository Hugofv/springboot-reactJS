/*
 * ServidorRepository.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.gov.mt.pge.pessoa.domain.Servidor;

/**
 * Classe de persistência referente a entidade {@link Servidor}.
 *
 * @author Squadra Tecnologia
 */
@Repository
public interface ServidorRepository extends JpaRepository<Servidor, Long> {

	/**
	 * Retorna a instância de {@link Servidor} com as dependências carregadas conforme o 'idPessoa' informado.
	 * 
	 * @param idPessoa
	 * @return
	 */
	@Query(" SELECT servidor FROM Servidor servidor " + 
		   " INNER JOIN FETCH servidor.pessoaFisica pessoaFisica " +
		   " INNER JOIN FETCH pessoaFisica.pessoa pessoa " +
		   "  LEFT JOIN FETCH pessoa.emails email " +
		   "  LEFT JOIN FETCH pessoa.telefones telefone " +
		   "  LEFT JOIN FETCH pessoa.enderecos endereco " +
		   " WHERE pessoa.id = :idPessoa ")
	public Servidor findByIdPessoaFetch(@Param("idPessoa") final Long idPessoa);
	
	/**
	 * Retorna o número de servidores que possuem a 'matrícula' informada
	 * desconsiderando o 'id' caso informado.
	 * 
	 * @param matricula
	 * @param id
	 * @return
	 */
	@Query("SELECT COUNT(servidor.id) FROM Servidor servidor WHERE servidor.matricula = :matricula AND (:id IS NULL OR servidor.id != :id)")
	public Long countByMatriculaAndIdNotIn(@Param("matricula") final String matricula, @Param("id") Long id);

}
