/*
 * PgePessoaApplication.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

/**
 * Classe principal de configuração e inicialização da aplicação.
 * 
 * @author Squadra Tecnologia
 */
@SpringBootApplication
@EntityScan(basePackageClasses = { PgePessoaApplication.class, Jsr310JpaConverters.class })
public class PgePessoaApplication {

	/**
	 * Ponto de inicialização do projeto.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(PgePessoaApplication.class, args);
	}
}
