/*
 * ServidorService.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.service;

import java.time.LocalDateTime;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.gov.mt.pge.comum.exception.BusinessException;
import br.gov.mt.pge.comum.util.Util;
import br.gov.mt.pge.pessoa.domain.PessoaFisica;
import br.gov.mt.pge.pessoa.domain.Servidor;
import br.gov.mt.pge.pessoa.exception.PgePessoaMessageCode;
import br.gov.mt.pge.pessoa.repository.ServidorRepository;

/**
 * Classe de négocio referente a entidade {@link Servidor}.
 * 
 * @author Squadra Tecnologia
 */
@Service
@Transactional(value = TxType.REQUIRED)
public class ServidorService {

	@Autowired
	private ServidorRepository servidorRepository;

	@Autowired
	private PessoaFisicaService pessoaFisicaService;

	/**
	 * Salva a instância de {@link Servidor} na base de dados conforme os critérios
	 * especificados na aplicação.
	 * 
	 * @param pessoa
	 * @return
	 */
	public Servidor salvar(Servidor servidor) {

		if (!Util.isEmpty(servidor.getMatricula())) {
			validarMatriculaCadastrado(servidor);
		}

		PessoaFisica pessoaFisica = pessoaFisicaService.salvar(servidor.getPessoaFisica());
		servidor.setPessoaFisica(pessoaFisica);

		if (servidor.getId() == null) {
			servidor.setDataInclusao(LocalDateTime.now());
		}

		return servidorRepository.save(servidor);
	}

	/**
	 * Retorna a instância de {@link Servidor} conforme o 'idPessoa' informado.
	 * 
	 * @param idPessoa
	 * @return
	 */
	public Servidor getServidorByIdPessoa(final Long idPessoa) {
		Servidor servidor = servidorRepository.findByIdPessoaFetch(idPessoa);

		if (servidor == null) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_NENHUM_REGISTRO_ENCONTRADO);
		}
		return servidor;
	}

	/**
	 * Verifica se a Matrícula vinculada a instância do {@link Servidor} já está
	 * cadastrada na base de dados.
	 * 
	 * @param pessoaFisica
	 */
	private void validarMatriculaCadastrado(final Servidor servidor) {
		Long count = servidorRepository.countByMatriculaAndIdNotIn(servidor.getMatricula(), servidor.getId());

		if (count > 0) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_MATRICULA_VINCULADO);
		}
	}

}
