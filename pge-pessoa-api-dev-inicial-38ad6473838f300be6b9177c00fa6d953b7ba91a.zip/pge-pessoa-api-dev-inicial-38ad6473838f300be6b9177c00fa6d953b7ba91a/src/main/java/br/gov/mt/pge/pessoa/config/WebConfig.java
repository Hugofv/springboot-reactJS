/*
 * WebConfig.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.config;

import org.springframework.context.annotation.Configuration;

import br.gov.mt.pge.api.config.PgeWebConfig;

/**
 * Classe de configuração referente aos recursos Web MVC da aplicação.
 * 
 * @author Squadra Tecnologia
 */
@Configuration
public class WebConfig extends PgeWebConfig {

}
