/*
 * SwaggerConfig.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.config;

import org.springframework.context.annotation.Configuration;

import br.gov.mt.pge.api.config.PgeSwaggerConfig;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Classe de configuração referente a geração de documentação automatida da API
 * REST.
 * 
 * @author Squadra Tecnologia
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig extends PgeSwaggerConfig {

}
