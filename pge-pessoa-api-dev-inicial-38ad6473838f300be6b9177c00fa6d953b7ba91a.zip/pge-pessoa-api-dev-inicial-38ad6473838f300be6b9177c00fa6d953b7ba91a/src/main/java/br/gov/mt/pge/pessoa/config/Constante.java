/*
 * Constante.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.config;

/**
 * Classe responsável por manter as constantes da aplicação.
 * 
 * @author Squadra Tecnologia
 */
public final class Constante {

	/**
	 * Construtor privado para garantir o singleton.
	 */
	private Constante() {
	}
}
