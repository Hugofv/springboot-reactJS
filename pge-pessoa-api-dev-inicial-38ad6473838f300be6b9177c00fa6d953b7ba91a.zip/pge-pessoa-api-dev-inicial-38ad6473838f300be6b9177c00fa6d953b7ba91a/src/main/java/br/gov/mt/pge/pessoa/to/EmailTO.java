/* 	 
 * EmailTO.java  
 * Copyright PGE-MT.  
 * 
 * Este software é confidencial e propriedade da PGE-MT.  
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.  
 * Este arquivo contém informações proprietárias.  
 */
package br.gov.mt.pge.pessoa.to;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.gov.mt.pge.pessoa.domain.Email;
import io.swagger.annotations.ApiModelProperty;

/**
 * Classe de transferência referente a entidade {@link Email}.
 * 
 * @author Squadra Tecnologia
 */
@JsonInclude(Include.NON_NULL)
public class EmailTO implements Serializable {

	private static final long serialVersionUID = -5002916458132571110L;

	@ApiModelProperty(value = "Código do E-mail")
	private Long id;

	@NotNull
	@Size(max = 100)
	@ApiModelProperty(value = "Descrição", required = true)
	private String descricao;

	@ApiModelProperty(value = "Determina qual será o e-mail principal")
	private boolean principal;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @return the principal
	 */
	public boolean isPrincipal() {
		return principal;
	}

	/**
	 * @param principal the principal to set
	 */
	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmailTO other = (EmailTO) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
