/*
 * PessoaJuridicaTO.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.to;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.gov.mt.pge.pessoa.domain.PessoaJuridica;
import io.swagger.annotations.ApiModelProperty;

/**
 * Classe de transferência referente a entidade {@link PessoaJuridica}.
 *
 * @author Squadra Tecnologia
 */
@JsonInclude(Include.NON_NULL)
public class PessoaJuridicaTO implements Serializable {

	private static final long serialVersionUID = 3823001043883141214L;

	@ApiModelProperty(value = "Código da Pessoa")
	private Long id;

	@NotNull
	@Size(max = 200)
	@ApiModelProperty(value = "Nome da Pessoa", required = true)
	private String nome;

	@Size(max = 200)
	@ApiModelProperty(value = "Nome Fantasia da Pessoa Jurídica")
	private String nomeFantasia;

	@NotNull
	@Size(max = 14)
	@ApiModelProperty(value = "CNPJ da Pessoa Jurídica", required = true)
	private String cnpj;

	@NotNull
	@Size(max = 11)
	@ApiModelProperty(value = "IE da Pessoa", required = true)
	private String ie;

	@Valid
	@ApiModelProperty(value = "Endereços")
	private List<EnderecoTO> enderecos;

	@Valid
	@ApiModelProperty(value = "Telefones")
	private List<TelefoneTO> telefones;

	@Valid
	@ApiModelProperty(value = "Emails")
	private List<EmailTO> emails;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the nomeFantasia
	 */
	public String getNomeFantasia() {
		return nomeFantasia;
	}

	/**
	 * @param nomeFantasia the nomeFantasia to set
	 */
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	/**
	 * @return the cnpj
	 */
	public String getCnpj() {
		return cnpj;
	}

	/**
	 * @param cnpj the cnpj to set
	 */
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	/**
	 * @return the ie
	 */
	public String getIe() {
		return ie;
	}

	/**
	 * @param ie the ie to set
	 */
	public void setIe(String ie) {
		this.ie = ie;
	}

	/**
	 * @return the enderecos
	 */
	public List<EnderecoTO> getEnderecos() {
		return enderecos;
	}

	/**
	 * @param enderecos the enderecos to set
	 */
	public void setEnderecos(List<EnderecoTO> enderecos) {
		this.enderecos = enderecos;
	}

	/**
	 * @return the telefones
	 */
	public List<TelefoneTO> getTelefones() {
		return telefones;
	}

	/**
	 * @param telefones the telefones to set
	 */
	public void setTelefones(List<TelefoneTO> telefones) {
		this.telefones = telefones;
	}

	/**
	 * @return the emails
	 */
	public List<EmailTO> getEmails() {
		return emails;
	}

	/**
	 * @param emails the emails to set
	 */
	public void setEmails(List<EmailTO> emails) {
		this.emails = emails;
	}

}
