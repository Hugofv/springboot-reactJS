/*
 * PessoaFisicaAdapter.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.adapter;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.gov.mt.pge.comum.util.Util;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.domain.PessoaFisica;
import br.gov.mt.pge.pessoa.service.PessoaFisicaService;
import br.gov.mt.pge.pessoa.to.EmailTO;
import br.gov.mt.pge.pessoa.to.EnderecoTO;
import br.gov.mt.pge.pessoa.to.PessoaFisicaTO;
import br.gov.mt.pge.pessoa.to.TelefoneTO;

/**
 * Classe adapter referente a entidade {@link PessoaFisica}.
 * 
 * @author Squadra Tecnologia
 */
@Component
public class PessoaFisicaAdapter extends PessoaAdapter {

	@Autowired
	private PessoaFisicaService pessoaFisicaService;

	/**
	 * Retorna a instância de {@link PessoaFisica} conforme a instância de
	 * {@link PessoaFisicaTO}.
	 * 
	 * @param pessoaFisicaTO
	 * @return
	 */
	public PessoaFisica getPessoaFisica(final PessoaFisicaTO pessoaFisicaTO) {
		Pessoa pessoa = new Pessoa();
		PessoaFisica pessoaFisica = new PessoaFisica();

		if (pessoaFisicaTO.getId() != null) {
			pessoaFisica = pessoaFisicaService.getPessoaFisicaByIdPessoa(pessoaFisicaTO.getId());
			pessoa = pessoaFisica.getPessoa();
		}

		addOrRemoveEmails(pessoa, pessoaFisicaTO.getEmails());
		addOrRemoveTelefones(pessoa, pessoaFisicaTO.getTelefones());
		addOrRemoveEnderecos(pessoa, pessoaFisicaTO.getEnderecos());

		// Pessoa Física
		pessoaFisica.setPessoa(pessoa);
		pessoa.setNome(pessoaFisicaTO.getNome());

		String rg = pessoaFisicaTO.getRg();
		pessoaFisica.setRg(rg);

		String cpf = Util.removerCaracteresNaoNumericos(pessoaFisicaTO.getCpf());
		pessoaFisica.setCpf(cpf);

		return pessoaFisica;
	}

	/**
	 * Retorna a instância de {@link PessoaFisicaTO} conforme a instância de
	 * {@link PessoaFisica}.
	 * 
	 * @param pessoaFisica
	 * @return
	 */
	public PessoaFisicaTO getPessoaFisicaTO(final PessoaFisica pessoaFisica) {
		PessoaFisicaTO pessoaFisicaTO = new PessoaFisicaTO();
		pessoaFisicaTO.setNome(pessoaFisica.getPessoa().getNome());
		pessoaFisicaTO.setId(pessoaFisica.getPessoa().getId());
		pessoaFisicaTO.setCpf(pessoaFisica.getCpf());
		pessoaFisicaTO.setRg(pessoaFisica.getRg());

		List<EmailTO> emailsTO = getEmailsTO(pessoaFisica.getPessoa());
		pessoaFisicaTO.setEmails(emailsTO);

		List<TelefoneTO> telefonesTO = getTelefonesTO(pessoaFisica.getPessoa());
		pessoaFisicaTO.setTelefones(telefonesTO);

		List<EnderecoTO> enderecosTO = getEnderecosTO(pessoaFisica.getPessoa());
		pessoaFisicaTO.setEnderecos(enderecosTO);

		return pessoaFisicaTO;
	}

}
