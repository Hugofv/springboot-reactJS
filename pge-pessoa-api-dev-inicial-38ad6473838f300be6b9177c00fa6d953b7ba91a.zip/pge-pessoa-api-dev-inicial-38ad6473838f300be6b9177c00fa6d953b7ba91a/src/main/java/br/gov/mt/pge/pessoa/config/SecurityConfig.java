/*
 * SecurityConfig.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import br.gov.mt.pge.api.config.PgeSecurityConfig;
import br.gov.mt.pge.api.security.AuthenticationProvider;
import br.gov.mt.pge.auth.service.AuthService;
import br.gov.mt.pge.pessoa.security.AuthenticationProviderImpl;

/**
 * Classe de configuração referente a segurança da aplicação.
 * 
 * @author Squadra Tecnologia
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends PgeSecurityConfig {

	/**
	 * Retorna a instância {@link AuthService}.
	 * 
	 * @return
	 */
	@Bean
	public AuthService authService() {
		return new AuthService();
	};

	/**
	 * @see br.gov.mt.pge.api.config.PgeSecurityConfig#authenticationProvider()
	 */
	@Override
	protected AuthenticationProvider authenticationProvider() {
		return new AuthenticationProviderImpl(authService());
	}

}
