/*
 * PessoaRepository.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.repository;

import java.util.List;

import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.to.FiltroPessoaTO;
import br.gov.mt.pge.pessoa.to.PessoaTO;

/**
 * Classe de persistência referente a entidade {@link Pessoa}.
 *
 * @author Squadra Tecnologia
 */
public interface PessoaRepositoryCustom {

	/**
	 * Retorna a lista de {@link PessoaTO} conforme o {@link FiltroPessoaTO}
	 * informado.
	 * 
	 * @param filtroTO
	 * @return
	 */
	public List<PessoaTO> getPessoasByFiltro(final FiltroPessoaTO filtroTO);
}
