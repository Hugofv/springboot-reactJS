/*
 * PessoaJuridicaRepository.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.gov.mt.pge.pessoa.domain.PessoaJuridica;

/**
 * Classe de persistência referente a entidade {@link PessoaJuridica}.
 *
 * @author Squadra Tecnologia
 */
@Repository
public interface PessoaJuridicaRepository extends JpaRepository<PessoaJuridica, Long> {
	
	/**
	 * Retorna a instância de {@link PessoaJuridica} com as dependências carregadas conforme o 'idPessoa' informado.
	 * 
	 * @param idPessoa
	 * @return
	 */
	@Query(" SELECT pessoaJuridica FROM PessoaJuridica pessoaJuridica " + 
		   " INNER JOIN FETCH pessoaJuridica.pessoa pessoa " +
		   "  LEFT JOIN FETCH pessoa.emails email " +
		   "  LEFT JOIN FETCH pessoa.telefones telefone " +
		   "  LEFT JOIN FETCH pessoa.enderecos endereco " +
		   " WHERE pessoa.id = :idPessoa ")
	public PessoaJuridica findByIdPessoaFetch(@Param("idPessoa") final Long idPessoa);

	/**
	 * Retorna o número de {@link PessoaJuridica} associado ao 'CNPJ',
	 * desconsiderando o 'id' caso informado.
	 * 
	 * @param cnpj
	 * @param id
	 * @return
	 */
	@Query("SELECT COUNT(pessoaJuridica.id) FROM PessoaJuridica pessoaJuridica WHERE pessoaJuridica.cnpj = :cnpj AND (:id IS NULL OR pessoaJuridica.id != :id)")
	public Long countByCnpjAndIdNotIn(@Param("cnpj") final String cnpj, @Param("id") final Long id);

	/**
	 * Retorna o número de {@link PessoaJuridica} associado ao 'IE', desconsiderando
	 * o 'id' caso informado.
	 * 
	 * @param ie
	 * @return
	 */
	@Query("SELECT COUNT(pessoaJuridica.id) FROM PessoaJuridica pessoaJuridica WHERE pessoaJuridica.ie = :ie AND (:id IS NULL OR pessoaJuridica.id != :id)")
	public Long countByIeAndIdNotIn(@Param("ie") final String ie, @Param("id") final Long id);

}
