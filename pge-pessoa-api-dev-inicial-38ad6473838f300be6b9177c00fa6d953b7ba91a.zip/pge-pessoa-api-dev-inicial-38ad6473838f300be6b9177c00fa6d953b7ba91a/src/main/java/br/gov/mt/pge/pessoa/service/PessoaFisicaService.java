/*
 * PessoaFisicaService.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.service;

import java.time.LocalDateTime;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.gov.mt.pge.comum.exception.BusinessException;
import br.gov.mt.pge.comum.util.CollectionUtil;
import br.gov.mt.pge.comum.util.Util;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.domain.PessoaFisica;
import br.gov.mt.pge.pessoa.exception.PgePessoaMessageCode;
import br.gov.mt.pge.pessoa.repository.PessoaFisicaRepository;
import br.gov.mt.pge.pessoa.repository.PessoaRepository;

/**
 * Classe de négocio referente a entidade {@link Pessoa}.
 * 
 * @author Squadra Tecnologia
 */
@Service
@Transactional(value = TxType.REQUIRED)
public class PessoaFisicaService {

	@Autowired
	private PessoaFisicaRepository pessoaFisicaRepository;

	@Autowired
	private PessoaRepository pessoaRepository;

	@Autowired
	private EmailService emailService;

	/**
	 * Salva a instânica de {@link PessoaFisica} na base de dados conforme os
	 * critérios especificados na aplicação.
	 * 
	 * @param pessoaFisica
	 * @return
	 */
	public PessoaFisica salvar(PessoaFisica pessoaFisica) {
		validarCpf(pessoaFisica.getCpf());
		validarCpfCadastrado(pessoaFisica);

		Pessoa pessoa = pessoaFisica.getPessoa();

		if (!CollectionUtil.isEmpty(pessoa.getEmails())) {
			emailService.validarEmailsCadastrados(pessoa.getEmails());
		}

		if (pessoa.getId() == null) {
			pessoa.setDataInclusao(LocalDateTime.now());
		}
		pessoa = pessoaRepository.save(pessoa);
		pessoaFisica.setPessoa(pessoa);

		return pessoaFisicaRepository.save(pessoaFisica);
	}

	/**
	 * Retorna a instância de {@link PessoaFisica} conforme o 'idPessoa' informado.
	 * 
	 * @param idPessoa
	 * @return
	 */
	public PessoaFisica getPessoaFisicaByIdPessoa(final Long idPessoa) {
		PessoaFisica pessoaFisica = pessoaFisicaRepository.findByIdPessoaFetch(idPessoa);

		if (pessoaFisica == null) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_NENHUM_REGISTRO_ENCONTRADO);
		}
		return pessoaFisica;
	}

	/**
	 * Verifica se o Cpf informado é válido.
	 * 
	 * @param cpf
	 */
	public void validarCpf(final String cpf) {
		if (!Util.isCpfValido(cpf)) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_CPF_INVALIDO);
		}
	}

	/**
	 * Valida se o CPF já está cadastrado na base de dados.
	 * 
	 * @param pessoaFisica
	 */
	private void validarCpfCadastrado(final PessoaFisica pessoaFisica) {
		Long count = pessoaFisicaRepository.countByCpfAndIdNotIn(pessoaFisica.getCpf(), pessoaFisica.getId());

		if (count > 0) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_CPF_CADASTRADO);
		}
	}

}
