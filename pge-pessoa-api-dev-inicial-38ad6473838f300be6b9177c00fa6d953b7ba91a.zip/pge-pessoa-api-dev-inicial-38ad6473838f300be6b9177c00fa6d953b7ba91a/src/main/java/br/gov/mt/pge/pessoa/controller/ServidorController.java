/*
 * ServidorController.java  
 * Copyright PGE-MT.  
 * 
 * Este software é confidencial e propriedade da PGE-MT.  
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.  
 * Este arquivo contém informações proprietárias.  
 */
package br.gov.mt.pge.pessoa.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.gov.mt.pge.comum.exception.MessageResponse;
import br.gov.mt.pge.pessoa.adapter.ServidorAdapter;
import br.gov.mt.pge.pessoa.domain.PessoaJuridica;
import br.gov.mt.pge.pessoa.domain.Servidor;
import br.gov.mt.pge.pessoa.service.ServidorService;
import br.gov.mt.pge.pessoa.to.PessoaFisicaTO;
import br.gov.mt.pge.pessoa.to.ServidorTO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Classe de controle referente a entidade {@link PessoaJuridica}.
 * 
 * @author Squadra Tecnologia
 */
@Api(tags = "Servidor API")
@RestController
@RequestMapping("${app.api.base}/servidores")
public class ServidorController extends AbstractController {
	
	@Autowired
	private ServidorAdapter servidorAdapter;
	
	@Autowired
	private ServidorService servidorService;
	
	/**
	 * Salva a instância de {@link ServidorTO} na base de dados.
	 * 
	 * @param servidorTO
	 * @return
	 */
	@PreAuthorize("isAuthenticated()")
	@ApiOperation(value = "Salva as informações do Servidor conforme os critérios especificados na aplicação.", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiResponses({
			@ApiResponse(code = 200, message = "Success", response = ServidorTO.class),
			@ApiResponse(code = 400, message = "Bad Request", response = MessageResponse.class), 
	})
	@PostMapping(path = "/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> salvar(@ApiParam(value = "Informações do Servidor", required = true) @Valid @RequestBody ServidorTO servidorTO) {
		Servidor servidor = servidorAdapter.getServidor(servidorTO);

		if (servidor.getId() == null) {
			Long idPessoa = getCredential().getIdPessoa();
			servidor.getPessoaFisica().getPessoa().setIdPessoaInclusao(idPessoa);
		}
		servidor = servidorService.salvar(servidor);
		servidorTO = servidorAdapter.getServidorTO(servidor);
		return ResponseEntity.ok(servidorTO);
	}

	/**
	 * Retorna a instância de {@link ServidorTO} conforme o 'idPessoa'
	 * informado.
	 * 
	 * @param idEstado
	 * @return
	 */
	@PreAuthorize("isAuthenticated()")
	@ApiOperation(value = "Recupera os do Servidor por código.", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiResponses({
			@ApiResponse(code = 200, message = "Success", response = PessoaFisicaTO.class),
			@ApiResponse(code = 400, message = "Bad Request", response = MessageResponse.class), 
			@ApiResponse(code = 404, message = "Not Found", response = MessageResponse.class)
	})
	@GetMapping(path = "/{idPessoa:[\\d]+}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<?> getServidorByIdPessoa(
			@ApiParam(value = "Código da Pessoa.", required = true) @PathVariable(required = true) final Long idPessoa) {
		Servidor servidor = servidorService.getServidorByIdPessoa(idPessoa);
		ServidorTO servidorTO = servidorAdapter.getServidorTO(servidor);
		return ResponseEntity.ok(servidorTO);
	}
}
