/*
 * PessoaFisicaRepository.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.gov.mt.pge.pessoa.domain.PessoaFisica;

/**
 * Classe de persistência referente a entidade {@link PessoaFisica}.
 *
 * @author Squadra Tecnologia
 */
@Repository
public interface PessoaFisicaRepository extends JpaRepository<PessoaFisica, Long> {

	/**
	 * Retorna a instância de {@link PessoaFisica} com as dependências carregadas conforme o 'idPessoa' informado.
	 * 
	 * @param idPessoa
	 * @return
	 */
	@Query(" SELECT pessoaFisica FROM PessoaFisica pessoaFisica " + 
		   " INNER JOIN FETCH pessoaFisica.pessoa pessoa " +
		   "  LEFT JOIN FETCH pessoa.emails email " +
		   "  LEFT JOIN FETCH pessoa.telefones telefone " +
		   "  LEFT JOIN FETCH pessoa.enderecos endereco " +
		   " WHERE pessoa.id = :idPessoa ")
	public PessoaFisica findByIdPessoaFetch(@Param("idPessoa") final Long idPessoa);

	/**
	 * Retorna o número de {@link PessoaFisica} associado ao 'CPF' desconsiderando o
	 * 'id' caso informado.
	 * 
	 * @param cpf
	 * @param id
	 * @return
	 */
	@Query("SELECT COUNT(pessoaFisica.id) FROM PessoaFisica pessoaFisica WHERE pessoaFisica.cpf = :cpf AND (:id IS NULL OR pessoaFisica.id != :id)")
	public Long countByCpfAndIdNotIn(@Param("cpf") final String cpf, @Param("id") final Long id);

}
