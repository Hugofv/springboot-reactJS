/*
 * AbstractController.java  
 * Copyright PGE-MT.  
 * 
 * Este software é confidencial e propriedade da PGE-MT.  
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.  
 * Este arquivo contém informações proprietárias.  
 */
package br.gov.mt.pge.pessoa.controller;

import org.springframework.security.core.context.SecurityContextHolder;

import br.gov.mt.pge.pessoa.security.CredentialImpl;

/**
 * Abstract Controller.
 * 
 * @author Squadra Tecnologia
 */
public abstract class AbstractController {

	/**
	 * Retorna a instância de {@link CredentialImpl}.
	 * 
	 * @return
	 */
	protected CredentialImpl getCredential() {
		return (CredentialImpl) SecurityContextHolder.getContext().getAuthentication().getCredentials();
	}

}
