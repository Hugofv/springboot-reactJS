/*
 * EnderecoAdapter.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.adapter;

import org.springframework.stereotype.Component;

import br.gov.mt.pge.comum.util.Util;
import br.gov.mt.pge.pessoa.domain.Endereco;
import br.gov.mt.pge.pessoa.to.EnderecoTO;

/**
 * Classe adapter referente a entidade {@link Endereco}.
 * 
 * @author Squadra Tecnologia
 */
@Component
public class EnderecoAdapter {

	/**
	 * Retorna a instância de {@link Endereco} conforme a instância de
	 * {@link EnderecoTO}.
	 * 
	 * @param enderecoTO
	 * @return
	 */
	public Endereco getEndereco(final EnderecoTO enderecoTO) {
		Endereco endereco = new Endereco();
		endereco.setId(enderecoTO.getId());
		endereco.setNumero(enderecoTO.getNumero());
		endereco.setBairro(enderecoTO.getBairro());
		endereco.setPrincipal(enderecoTO.isPrincipal());
		endereco.setLogradouro(enderecoTO.getLogradouro());
		endereco.setComplemento(enderecoTO.getComplemento());
		endereco.setIdMunicipio(enderecoTO.getIdMunicipio());

		String cep = Util.removerCaracteresNaoNumericos(enderecoTO.getCep());
		endereco.setCep(cep);

		return endereco;
	}

	/**
	 * Retorna a instância de {@link EnderecoTO} conforme a instância de
	 * {@link Endereco}.
	 * 
	 * @param endereco
	 * @return
	 */
	public EnderecoTO getEnderecoTO(final Endereco endereco) {
		EnderecoTO enderecoTO = new EnderecoTO();
		enderecoTO.setId(endereco.getId());
		enderecoTO.setCep(endereco.getCep());
		enderecoTO.setNumero(endereco.getNumero());
		enderecoTO.setBairro(endereco.getBairro());
		enderecoTO.setPrincipal(endereco.isPrincipal());
		enderecoTO.setLogradouro(endereco.getLogradouro());
		enderecoTO.setComplemento(endereco.getComplemento());
		enderecoTO.setIdMunicipio(endereco.getIdMunicipio());

		return enderecoTO;
	}
}
