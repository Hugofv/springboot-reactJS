/*
 * EmailService.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.service;

import java.util.Set;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.gov.mt.pge.comum.exception.BusinessException;
import br.gov.mt.pge.pessoa.domain.Email;
import br.gov.mt.pge.pessoa.exception.PgePessoaMessageCode;
import br.gov.mt.pge.pessoa.repository.EmailRepository;

/**
 * Classe de négocio referente a entidade {@link Email}.
 *
 * @author Squadra Tecnologia
 */
@Service
@Transactional(value = TxType.REQUIRED)
public class EmailService {

	@Autowired
	private EmailRepository emailRepository;

	/**
	 * Verifica se algum dos e-mails da lista informada já está cadastrado na base
	 * de dados.
	 * 
	 * @param email
	 */
	public void validarEmailsCadastrados(final Set<Email> emails) {
		for (Email email : emails) {
			validarEmailCadastrado(email);
		}
	}

	/**
	 * Verifica se o e-mail já está cadastrado na base de dados.
	 * 
	 * @param email
	 */
	private void validarEmailCadastrado(final Email email) {
		Long count = emailRepository.countByDescricaoAndIdPessoaNotIn(email.getDescricao(), email.getPessoa().getId());

		if (count > 0) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_EMAIL_CADASTRADO, email.getDescricao());
		}
	}

}
