/*
 * EmailRepository.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.gov.mt.pge.pessoa.domain.Email;

/**
 * Classe de persistência referente a entidade {@link Email}.
 *
 * @author Squadra Tecnologia
 */
@Repository
public interface EmailRepository extends JpaRepository<Email, Long> {

	/**
	 * Retorna o número de e-mails encontrados na base de dados desconsiderando o
	 * 'idPessoa' caso informado.
	 * 
	 * @param descricao
	 * @param idPessoa
	 * @return
	 */
	@Query("SELECT COUNT(email.id) FROM Email email INNER JOIN email.pessoa pessoa WHERE email.descricao = :descricao AND (:idPessoa IS NULL OR pessoa.id != :idPessoa)")
	public Long countByDescricaoAndIdPessoaNotIn(@Param("descricao") final String descricao, @Param("idPessoa") final Long idPessoa);

}
