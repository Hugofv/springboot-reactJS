/* 	 
 * Servidor.java  
 * Copyright PGE-MT.  
 * 
 * Este software é confidencial e propriedade da PGE-MT.  
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.  
 * Este arquivo contém informações proprietárias.  
 */
package br.gov.mt.pge.pessoa.domain;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

/**
 * Classe de representação de 'Servidor'.
 * 
 * @author Squadra Tecnologia
 */
@Entity
@Audited
@Table(name = "TB_SERVIDOR")
public class Servidor implements Serializable {

	private static final long serialVersionUID = 3639706313916572818L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PK_SERVIDOR", nullable = false)
	private Long id;

	@Column(name = "ID_ORGAO", nullable = false)
	private Long idOrgao;

	@Column(name = "ID_DEPARTAMENTO", nullable = true)
	private Long idDepartamento;

	@Column(name = "NR_MATRICULA", nullable = true, length = 10)
	private String matricula;

	@Column(name = "DT_INCLUSAO", nullable = false)
	private LocalDateTime dataInclusao;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_PESSOA_FISICA", referencedColumnName = "PK_PESSOA_FISICA", nullable = false)
	private PessoaFisica pessoaFisica;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_TIPO_SITUACAO_SERVIDOR", referencedColumnName = "PK_TIPO_SITUACAO_SERVIDOR", nullable = false)
	private TipoSituacaoServidor situacao;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the idOrgao
	 */
	public Long getIdOrgao() {
		return idOrgao;
	}

	/**
	 * @param idOrgao the idOrgao to set
	 */
	public void setIdOrgao(Long idOrgao) {
		this.idOrgao = idOrgao;
	}

	/**
	 * @return the idDepartamento
	 */
	public Long getIdDepartamento() {
		return idDepartamento;
	}

	/**
	 * @param idDepartamento the idDepartamento to set
	 */
	public void setIdDepartamento(Long idDepartamento) {
		this.idDepartamento = idDepartamento;
	}

	/**
	 * @return the matricula
	 */
	public String getMatricula() {
		return matricula;
	}

	/**
	 * @param matricula the matricula to set
	 */
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	/**
	 * @return the situacao
	 */
	public TipoSituacaoServidor getSituacao() {
		return situacao;
	}

	/**
	 * @param situacao the situacao to set
	 */
	public void setSituacao(TipoSituacaoServidor situacao) {
		this.situacao = situacao;
	}

	/**
	 * @return the pessoaFisica
	 */
	public PessoaFisica getPessoaFisica() {
		return pessoaFisica;
	}

	/**
	 * @param pessoaFisica the pessoaFisica to set
	 */
	public void setPessoaFisica(PessoaFisica pessoaFisica) {
		this.pessoaFisica = pessoaFisica;
	}

	/**
	 * @return the dataInclusao
	 */
	public LocalDateTime getDataInclusao() {
		return dataInclusao;
	}

	/**
	 * @param dataInclusao the dataInclusao to set
	 */
	public void setDataInclusao(LocalDateTime dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Servidor other = (Servidor) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
