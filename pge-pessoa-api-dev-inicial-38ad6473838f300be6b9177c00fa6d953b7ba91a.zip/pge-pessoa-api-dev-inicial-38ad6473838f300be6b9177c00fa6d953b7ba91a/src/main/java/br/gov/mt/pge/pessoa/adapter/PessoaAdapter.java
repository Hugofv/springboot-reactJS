/*
 * PessoaAdapter.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.adapter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.gov.mt.pge.comum.util.CollectionUtil;
import br.gov.mt.pge.pessoa.domain.Email;
import br.gov.mt.pge.pessoa.domain.Endereco;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.domain.Telefone;
import br.gov.mt.pge.pessoa.to.EmailTO;
import br.gov.mt.pge.pessoa.to.EnderecoTO;
import br.gov.mt.pge.pessoa.to.TelefoneTO;

/**
 * Classe adapter referente a entidade {@link Pessoa}.
 * 
 * @author Squadra Tecnologia
 */
@Component
public class PessoaAdapter {

	@Autowired
	private EmailAdapter emailAdapter;

	@Autowired
	private EnderecoAdapter enderecoAdapter;

	@Autowired
	private TelefoneAdapter telefoneAdapter;

	/**
	 * Adiciona ou Remove e-mails conforme a lista de {@link EmailTO} na instância
	 * de {@link Pessoa}.
	 * 
	 * @param pessoa
	 * @param emailsTO
	 */
	protected void addOrRemoveEmails(Pessoa pessoa, final List<EmailTO> emailsTO) {
		if (CollectionUtil.isEmpty(emailsTO)) {
			pessoa.setEmails(new HashSet<Email>());
		} else {
			Set<Email> emails = new HashSet<Email>();

			emailsTO.forEach(emailTO -> {
				Email email = emailAdapter.getEmail(emailTO);
				email.setPessoa(pessoa);
				emails.add(email);
			});
			pessoa.setEmails(emails);
		}
	}

	/**
	 * Adiciona ou Remove telefones conforme a lista de {@link TelefoneTO} na
	 * instância de {@link Pessoa}.
	 * 
	 * @param pessoa
	 * @param telefonesTO
	 */
	protected void addOrRemoveTelefones(Pessoa pessoa, final List<TelefoneTO> telefonesTO) {
		if (CollectionUtil.isEmpty(telefonesTO)) {
			pessoa.setTelefones(new HashSet<Telefone>());
		} else {
			Set<Telefone> telefones = new HashSet<Telefone>();

			telefonesTO.forEach(telefoneTO -> {
				Telefone telefone = telefoneAdapter.getTelefone(telefoneTO);
				telefone.setPessoa(pessoa);
				telefones.add(telefone);
			});
			pessoa.setTelefones(telefones);
		}
	}

	/**
	 * Adiciona ou Remove endereços conforme a lista de {@link EnderecoTO} na
	 * instância de {@link Pessoa}.
	 * 
	 * @param pessoa
	 * @param enderecosTO
	 */
	protected void addOrRemoveEnderecos(Pessoa pessoa, final List<EnderecoTO> enderecosTO) {
		if (CollectionUtil.isEmpty(enderecosTO)) {
			pessoa.setEnderecos(new HashSet<Endereco>());
		} else {
			Set<Endereco> enderecos = new HashSet<Endereco>();

			enderecosTO.forEach(enderecoTO -> {
				Endereco endereco = enderecoAdapter.getEndereco(enderecoTO);
				endereco.setPessoa(pessoa);
				enderecos.add(endereco);
			});
			pessoa.setEnderecos(enderecos);
		}
	}

	/**
	 * Retorna a lista de {@link EmailTO} conforme a instância de {@link Pessoa}
	 * informada.
	 * 
	 * @param pessoa
	 * @return
	 */
	protected List<EmailTO> getEmailsTO(final Pessoa pessoa) {
		List<EmailTO> emailsTO = new ArrayList<EmailTO>();

		if (!CollectionUtil.isEmpty(pessoa.getEmails())) {
			pessoa.getEmails().forEach(email -> {
				EmailTO emailTO = emailAdapter.getEmailTO(email);
				emailsTO.add(emailTO);
			});
		}
		return emailsTO;
	}

	/**
	 * Retorna a lista de {@link TelefoneTO} conforme a instância de {@link Pessoa}
	 * informada.
	 * 
	 * @param pessoa
	 * @return
	 */
	protected List<TelefoneTO> getTelefonesTO(final Pessoa pessoa) {
		List<TelefoneTO> telefonesTO = new ArrayList<TelefoneTO>();

		if (!CollectionUtil.isEmpty(pessoa.getTelefones())) {
			pessoa.getTelefones().forEach(telefone -> {
				TelefoneTO telefoneTO = telefoneAdapter.geTelefoneTO(telefone);
				telefonesTO.add(telefoneTO);
			});
		}
		return telefonesTO;
	}

	/**
	 * Retorna a lista de {@link EnderecoTO} conforme a instância de {@link Pessoa}
	 * informada.
	 * 
	 * @param pessoa
	 * @return
	 */
	protected List<EnderecoTO> getEnderecosTO(final Pessoa pessoa) {
		List<EnderecoTO> enderecosTO = new ArrayList<EnderecoTO>();

		if (!CollectionUtil.isEmpty(pessoa.getEnderecos())) {
			pessoa.getEnderecos().forEach(endereco -> {
				EnderecoTO enderecoTO = enderecoAdapter.getEnderecoTO(endereco);
				enderecosTO.add(enderecoTO);
			});
		}
		return enderecosTO;
	}
}
