/*
 * ServidorAdapter.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.adapter;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.gov.mt.pge.comum.util.Util;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.domain.PessoaFisica;
import br.gov.mt.pge.pessoa.domain.Servidor;
import br.gov.mt.pge.pessoa.domain.TipoSituacaoServidor;
import br.gov.mt.pge.pessoa.service.ServidorService;
import br.gov.mt.pge.pessoa.to.EmailTO;
import br.gov.mt.pge.pessoa.to.EnderecoTO;
import br.gov.mt.pge.pessoa.to.ServidorTO;
import br.gov.mt.pge.pessoa.to.TelefoneTO;

/**
 * Classe adapter referente a entidade {@link Servidor}.
 * 
 * @author Squadra Tecnologia
 */
@Component
public class ServidorAdapter extends PessoaAdapter {

	@Autowired
	private ServidorService servidorService;

	/**
	 * Retorna a instância do {@link Servidor} conforme a instância de
	 * {@link ServidorTO}.
	 * 
	 * @param servidorTO
	 * @return
	 */
	public Servidor getServidor(final ServidorTO servidorTO) {

		Pessoa pessoa = new Pessoa();
		Servidor servidor = new Servidor();
		PessoaFisica pessoaFisica = new PessoaFisica();

		if (servidorTO.getId() != null) {
			servidor = servidorService.getServidorByIdPessoa(servidorTO.getId());
			pessoaFisica = servidor.getPessoaFisica();
			pessoa = pessoaFisica.getPessoa();
		}

		addOrRemoveEmails(pessoa, servidorTO.getEmails());
		addOrRemoveTelefones(pessoa, servidorTO.getTelefones());
		addOrRemoveEnderecos(pessoa, servidorTO.getEnderecos());

		// Pessoa Física
		pessoaFisica.setPessoa(pessoa);
		pessoa.setNome(servidorTO.getNome());

		String rg = servidorTO.getRg();
		pessoaFisica.setRg(rg);

		String cpf = Util.removerCaracteresNaoNumericos(servidorTO.getCpf());
		pessoaFisica.setCpf(cpf);

		// Servidor
		servidor.setPessoaFisica(pessoaFisica);
		servidor.setMatricula(servidorTO.getMatricula());
		servidor.setIdOrgao(servidorTO.getIdOrgaoServidor());

		// TipoSituacaoServidor
		TipoSituacaoServidor situacao = servidor.getSituacao();

		if (situacao == null || !situacao.getId().equals(servidorTO.getIdSituacaoServidor())) {
			situacao = new TipoSituacaoServidor();
			situacao.setId(servidorTO.getIdSituacaoServidor());
			servidor.setSituacao(situacao);
		}

		return servidor;
	}

	/**
	 * Retorna a instância de {@link ServidorTO} conforme a instância de
	 * {@link Servidor}.
	 * 
	 * @param servidor
	 * @return
	 */
	public ServidorTO getServidorTO(final Servidor servidor) {
		ServidorTO servidorTO = new ServidorTO();
		servidorTO.setNome(servidor.getPessoaFisica().getPessoa().getNome());
		servidorTO.setId(servidor.getPessoaFisica().getPessoa().getId());
		servidorTO.setIdSituacaoServidor(servidor.getSituacao().getId());
		servidorTO.setCpf(servidor.getPessoaFisica().getCpf());
		servidorTO.setRg(servidor.getPessoaFisica().getRg());
		servidorTO.setIdOrgaoServidor(servidor.getIdOrgao());
		servidorTO.setMatricula(servidor.getMatricula());

		List<EmailTO> emailsTO = getEmailsTO(servidor.getPessoaFisica().getPessoa());
		servidorTO.setEmails(emailsTO);

		List<TelefoneTO> telefonesTO = getTelefonesTO(servidor.getPessoaFisica().getPessoa());
		servidorTO.setTelefones(telefonesTO);

		List<EnderecoTO> enderecosTO = getEnderecosTO(servidor.getPessoaFisica().getPessoa());
		servidorTO.setEnderecos(enderecosTO);

		return servidorTO;
	}
}
