/*
 * TelefoneAdapter.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.adapter;

import org.springframework.stereotype.Component;

import br.gov.mt.pge.comum.util.Util;
import br.gov.mt.pge.pessoa.domain.Telefone;
import br.gov.mt.pge.pessoa.to.TelefoneTO;

/**
 * Classe adapter referente a entidade {@link Telefone}.
 * 
 * @author Squadra Tecnologia
 */
@Component
public class TelefoneAdapter {

	/**
	 * Retorna a instância de {@link Telefone} conforme a instância de
	 * {@link TelefoneTO} informado.
	 * 
	 * @param telefoneTO
	 * @return
	 */
	public Telefone getTelefone(final TelefoneTO telefoneTO) {
		Telefone telefone = new Telefone();
		telefone.setId(telefoneTO.getId());
		telefone.setPrincipal(telefoneTO.isPrincipal());

		String numero = Util.removerCaracteresNaoNumericos(telefoneTO.getNumero());
		telefone.setNumero(numero);

		return telefone;
	}

	/**
	 * Retorna a instância de {@link TelefoneTO} conforme a instância de
	 * {@link Telefone} informado.
	 * 
	 * @param telefone
	 * @return
	 */
	public TelefoneTO geTelefoneTO(final Telefone telefone) {
		TelefoneTO telefoneTO = new TelefoneTO();
		telefoneTO.setId(telefone.getId());
		telefoneTO.setNumero(telefone.getNumero());
		telefoneTO.setPrincipal(telefone.isPrincipal());
		return telefoneTO;

	}
}
