/*
 * PessoaService.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.service;

import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.gov.mt.pge.comum.exception.BusinessException;
import br.gov.mt.pge.comum.util.CollectionUtil;
import br.gov.mt.pge.comum.util.Util;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.exception.PgePessoaMessageCode;
import br.gov.mt.pge.pessoa.repository.PessoaRepository;
import br.gov.mt.pge.pessoa.to.FiltroPessoaTO;
import br.gov.mt.pge.pessoa.to.PessoaTO;

/**
 * Classe de négocio referente a entidade {@link Pessoa}.
 * 
 * @author Squadra Tecnologia
 */
@Service
@Transactional(value = TxType.REQUIRED)
public class PessoaService {

	@Autowired
	private PessoaRepository pessoaRepository;

	@Autowired
	private PessoaFisicaService pessoaFisicaService;

	@Autowired
	private PessoaJuridicaService pessoaJuridicaService;

	/**
	 * Retorna a lista de {@link PessoaTO} conforme os critérios de pesquisa
	 * informado na instância de {@link FiltroPessoaTO}.
	 * 
	 * @param filtroTO
	 * @return
	 */
	public List<PessoaTO> getPessoasByFiltro(final FiltroPessoaTO filtroTO) {

		validarFiltroObrigatorio(filtroTO);

		if (!Util.isEmpty(filtroTO.getCpf())) {
			pessoaFisicaService.validarCpf(filtroTO.getCpf());
		}

		if (!Util.isEmpty(filtroTO.getCnpj())) {
			pessoaJuridicaService.validarCnpj(filtroTO.getCnpj());
		}

		if (!Util.isEmpty(filtroTO.getIe())) {
			pessoaJuridicaService.validarIe(filtroTO.getIe());
		}

		List<PessoaTO> pessoasTO = pessoaRepository.getPessoasByFiltro(filtroTO);

		if (CollectionUtil.isEmpty(pessoasTO)) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_NENHUM_REGISTRO_ENCONTRADO);
		}

		return pessoasTO;
	}

	/**
	 * Verifica se ao menos um filtro de pesquisa foi informado.
	 * 
	 * @param filtroTO
	 */
	private void validarFiltroObrigatorio(final FiltroPessoaTO filtroTO) {
		boolean vazio = Boolean.TRUE;

		if (filtroTO.getId() != null) {
			vazio = Boolean.FALSE;
		}

		if (!Util.isEmpty(filtroTO.getNome())) {
			vazio = Boolean.FALSE;
		}

		if (!Util.isEmpty(filtroTO.getCpf())) {
			vazio = Boolean.FALSE;
		}

		if (!Util.isEmpty(filtroTO.getRg())) {
			vazio = Boolean.FALSE;
		}

		if (!Util.isEmpty(filtroTO.getCnpj())) {
			vazio = Boolean.FALSE;
		}

		if (!Util.isEmpty(filtroTO.getIe())) {
			vazio = Boolean.FALSE;
		}

		if (vazio) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_FILTRO_OBRIGATORIO);
		}
	}

}
