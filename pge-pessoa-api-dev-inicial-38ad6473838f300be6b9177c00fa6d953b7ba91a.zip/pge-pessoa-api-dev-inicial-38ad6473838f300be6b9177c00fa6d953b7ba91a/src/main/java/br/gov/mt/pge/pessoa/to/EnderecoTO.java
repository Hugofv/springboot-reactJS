/*
 * EnderecoTO.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.to;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.gov.mt.pge.pessoa.domain.Endereco;
import io.swagger.annotations.ApiModelProperty;

/**
 * Classe de transferência referente a entidade {@link Endereco}.
 *
 * @author Squadra Tecnologia
 */
@JsonInclude(Include.NON_NULL)
public class EnderecoTO implements Serializable {

	private static final long serialVersionUID = 1029313211860575464L;

	@ApiModelProperty(value = "Código do Endreço")
	private Long id;

	@NotNull
	@Size(max = 200)
	@ApiModelProperty(value = "Logradouro", required = true)
	private String logradouro;

	@NotNull
	@Size(max = 10)
	@ApiModelProperty(value = "Número", required = true)
	private String numero;

	@NotNull
	@Size(max = 60)
	@ApiModelProperty(value = "Bairro", required = true)
	private String bairro;

	@Size(max = 200)
	@ApiModelProperty(value = "Complemento")
	private String complemento;

	@NotNull
	@Size(max = 8)
	@ApiModelProperty(value = "CEP", required = true)
	private String cep;

	@NotNull
	@ApiModelProperty(value = "Município", required = true)
	private Long idMunicipio;

	@ApiModelProperty(value = "Determina qual será o endreço principal")
	private boolean principal;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the logradouro
	 */
	public String getLogradouro() {
		return logradouro;
	}

	/**
	 * @param logradouro the logradouro to set
	 */
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	/**
	 * @return the numero
	 */
	public String getNumero() {
		return numero;
	}

	/**
	 * @param numero the numero to set
	 */
	public void setNumero(String numero) {
		this.numero = numero;
	}

	/**
	 * @return the bairro
	 */
	public String getBairro() {
		return bairro;
	}

	/**
	 * @param bairro the bairro to set
	 */
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	/**
	 * @return the complemento
	 */
	public String getComplemento() {
		return complemento;
	}

	/**
	 * @param complemento the complemento to set
	 */
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	/**
	 * @return the cep
	 */
	public String getCep() {
		return cep;
	}

	/**
	 * @param cep the cep to set
	 */
	public void setCep(String cep) {
		this.cep = cep;
	}

	/**
	 * @return the idMunicipio
	 */
	public Long getIdMunicipio() {
		return idMunicipio;
	}

	/**
	 * @param idMunicipio the idMunicipio to set
	 */
	public void setIdMunicipio(Long idMunicipio) {
		this.idMunicipio = idMunicipio;
	}

	/**
	 * @return the principal
	 */
	public boolean isPrincipal() {
		return principal;
	}

	/**
	 * @param principal the principal to set
	 */
	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}

}
