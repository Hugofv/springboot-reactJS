/*
 * AuthenticationProviderImpl.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.security;

import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import br.gov.mt.pge.api.security.AuthenticationProvider;
import br.gov.mt.pge.auth.service.AuthService;
import br.gov.mt.pge.auth.to.UsuarioTO;
import br.gov.mt.pge.comum.exception.BusinessException;

/**
 * Classe responsável por prover a instância de {@link Authentication} com as
 * credenciais do Usuário logado.
 * 
 * @author Squadra Tecnologia
 */
public class AuthenticationProviderImpl implements AuthenticationProvider {

	private final Log logger = LogFactory.getLog(getClass());

	private AuthService authService;

	/**
	 * Construtor da classe.
	 * 
	 * @param authService
	 */
	public AuthenticationProviderImpl(final AuthService authService) {
		this.authService = authService;
	}

	/**
	 * @see br.gov.mt.pge.api.security.AuthenticationProvider#getAuthentication(java.lang.String)
	 */
	@Override
	public Authentication getAuthentication(String token) {
		Authentication authentication = null;

		try {
			UsuarioTO usuarioTO = authService.getInfoByToken(token);

			if (usuarioTO != null) {
				authentication = new UsernamePasswordAuthenticationToken(usuarioTO.getNome(),
						CredentialImpl.newInstance(usuarioTO, token), new ArrayList<GrantedAuthority>());
			}
		} catch (BusinessException e) {
			logger.error("Acesso negado.", e);
		}
		return authentication;
	}

}
