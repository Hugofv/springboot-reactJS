/*
 * EmailAdapter.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.adapter;

import org.springframework.stereotype.Component;

import br.gov.mt.pge.pessoa.domain.Email;
import br.gov.mt.pge.pessoa.to.EmailTO;

/**
 * Classe adapter referente a entidade {@link Email}.
 * 
 * @author Squadra Tecnologia
 */
@Component
public class EmailAdapter {

	/**
	 * Retorna a instância de {@link Email} conforme a instância de {@link EmailTO}.
	 * 
	 * @param emailTO
	 * @return
	 */
	public Email getEmail(final EmailTO emailTO) {
		Email email = new Email();
		email.setId(emailTO.getId());
		email.setDescricao(emailTO.getDescricao());
		email.setPrincipal(emailTO.isPrincipal());
		return email;
	}

	/**
	 * Retorna a instância de {@link EmailTO} conforme a instância de {@link Email}.
	 * 
	 * @param email
	 * @return
	 */
	public EmailTO getEmailTO(Email email) {
		EmailTO emailTO = new EmailTO();
		emailTO.setId(email.getId());
		emailTO.setDescricao(email.getDescricao());
		emailTO.setPrincipal(email.isPrincipal());
		return emailTO;
	}
}
