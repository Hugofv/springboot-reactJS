/* 	 
 * TelefoneTO.java  
 * Copyright PGE-MT.  
 * 
 * Este software é confidencial e propriedade da PGE-MT.  
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.  
 * Este arquivo contém informações proprietárias.  
 */
package br.gov.mt.pge.pessoa.to;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.gov.mt.pge.pessoa.domain.Telefone;
import io.swagger.annotations.ApiModelProperty;

/**
 * Classe de transferência referente a entidade {@link Telefone}.
 * 
 * @author Squadra Tecnologia
 */
@JsonInclude(Include.NON_NULL)
public class TelefoneTO implements Serializable {

	private static final long serialVersionUID = 4776459127485009645L;

	@ApiModelProperty(value = "Código do Telefone")
	private Long id;

	@NotNull
	@Size(max = 11)
	@ApiModelProperty(value = "Número", required = true)
	private String numero;

	@ApiModelProperty(value = "Determina qual será o telefone principal")
	private boolean principal;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the numero
	 */
	public String getNumero() {
		return numero;
	}

	/**
	 * @param numero the numero to set
	 */
	public void setNumero(String numero) {
		this.numero = numero;
	}

	/**
	 * @return the principal
	 */
	public boolean isPrincipal() {
		return principal;
	}

	/**
	 * @param principal the principal to set
	 */
	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}

}
