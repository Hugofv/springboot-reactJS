/* 	 
 * Audit.java  
 * Copyright PGE-MT.  
 * 
 * Este software é confidencial e propriedade da PGE-MT.  
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.  
 * Este arquivo contém informações proprietárias.  
 */
package br.gov.mt.pge.pessoa.domain;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.RevisionEntity;
import org.hibernate.envers.RevisionNumber;
import org.hibernate.envers.RevisionTimestamp;

import br.gov.mt.pge.pessoa.repository.audit.AuditListener;

/**
 * Classe de auditoria da aplicação.
 * 
 * @author Squadra Tecnologia
 */
@Entity
@Table(name = "TB_AUDIT")
@RevisionEntity(AuditListener.class)
public class Audit implements Serializable {

	private static final long serialVersionUID = 5273907092630655740L;

	@Id
	@RevisionNumber
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PK_AUDIT", nullable = false)
	private Long id;

	@RevisionTimestamp
	@Column(name = "NR_REVISION", nullable = false)
	private Long revision;

	@Column(name = "ID_PESSOA", nullable = false)
	private Long idPessoa;

	@Column(name = "DT_INCLUSAO", nullable = false)
	private LocalDateTime dataInclusao;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the idPessoa
	 */
	public Long getIdPessoa() {
		return idPessoa;
	}

	/**
	 * @param idPessoa the idPessoa to set
	 */
	public void setIdPessoa(Long idPessoa) {
		this.idPessoa = idPessoa;
	}

	/**
	 * @return the revision
	 */
	public Long getRevision() {
		return revision;
	}

	/**
	 * @param revision the revision to set
	 */
	public void setRevision(Long revision) {
		this.revision = revision;
	}

	/**
	 * @return the dataInclusao
	 */
	public LocalDateTime getDataInclusao() {
		return dataInclusao;
	}

	/**
	 * @param dataInclusao the dataInclusao to set
	 */
	public void setDataInclusao(LocalDateTime dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

}
