/*
 * PessoaRepositoryImpl.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.repository.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import br.gov.mt.pge.comum.util.Util;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.repository.PessoaRepositoryCustom;
import br.gov.mt.pge.pessoa.to.FiltroPessoaTO;
import br.gov.mt.pge.pessoa.to.PessoaTO;

/**
 * Classe de persistência referente a entidade {@link Pessoa}.
 *
 * @author Squadra Tecnologia
 */
@Repository
public class PessoaRepositoryImpl implements PessoaRepositoryCustom {

	@Autowired
	private EntityManager entityManager;

	/**
	 * @see br.gov.mt.pge.pessoa.repository.PessoaRepositoryCustom#getPessoasByFiltro(br.gov.mt.pge.pessoa.to.FiltroPessoaTO)
	 */
	@Override
	public List<PessoaTO> getPessoasByFiltro(final FiltroPessoaTO filtroTO) {
		Map<String, Object> parametros = new HashMap<>();

		StringBuilder jpql = new StringBuilder();
		jpql.append(" SELECT NEW br.gov.mt.pge.pessoa.to.PessoaTO(pessoa.id, pessoa.nome, ");
		jpql.append(" pessoaFisica.cpf, pessoaJuridica.cnpj, pessoaFisica.rg, pessoaJuridica.ie, ");
		jpql.append(" servidor.idOrgao, servidor.matricula) FROM Pessoa pessoa ");
		jpql.append(" LEFT JOIN pessoa.pessoaJuridica pessoaJuridica ");
		jpql.append(" LEFT JOIN pessoa.pessoaFisica pessoaFisica ");
		jpql.append(" LEFT JOIN pessoaFisica.servidor servidor ");
		jpql.append(" WHERE 1 = 1 ");

		if (filtroTO.getId() != null) {
			jpql.append(" AND pessoa.id = :id");
			parametros.put("id", filtroTO.getId());
		}

		if (!Util.isEmpty(filtroTO.getCnpj())) {
			jpql.append(" AND pessoaJuridica.cnpj = :cnpj ");
			parametros.put("cnpj", filtroTO.getCnpj());
		}

		if (!Util.isEmpty(filtroTO.getCpf())) {
			jpql.append(" AND pessoaFisica.cpf = :cpf ");
			parametros.put("cpf", filtroTO.getCpf());
		}

		if (!Util.isEmpty(filtroTO.getIe())) {
			jpql.append(" AND pessoaJuridica.ie = :ie");
			parametros.put("ie", filtroTO.getIe());
		}

		if (!Util.isEmpty(filtroTO.getRg())) {
			jpql.append(" AND pessoaFisica.rg = :rg");
			parametros.put("rg", filtroTO.getRg());
		}

		if (!Util.isEmpty(filtroTO.getNome())) {
			jpql.append(" AND UPPER(pessoa.nome) LIKE UPPER(:nome || '%') ");
			parametros.put("nome", filtroTO.getNome().trim());
		}

		TypedQuery<PessoaTO> query = entityManager.createQuery(jpql.toString(), PessoaTO.class);
		parametros.entrySet().forEach(parametro -> query.setParameter(parametro.getKey(), parametro.getValue()));

		if (filtroTO.getFirstResult() != null) {
			query.setFirstResult(filtroTO.getFirstResult());
		}

		if (filtroTO.getMaxResults() != null) {
			query.setMaxResults(filtroTO.getMaxResults());
		}

		return query.getResultList();
	}

}
