/*
 * PgePessoaMessageCode.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.exception;

import br.gov.mt.pge.comum.exception.MessageCode;

/**
 * Enum com os código de exceções/mensagens de negócio.
 * 
 * @author Squadra Tecnologia S/A.
 */
public enum PgePessoaMessageCode implements MessageCode {

	ERRO_INESPERADO("ME001", 500), 
	ERRO_CAMPOS_OBRIGATORIOS("ME002", 400),
	ERRO_CPF_INVALIDO("ME003", 400),
	ERRO_CNPJ_INVALIDO("ME004", 400),
	ERRO_IE_INVALIDO("ME005", 400),
	ERRO_CPF_CADASTRADO("ME006", 400),
	ERRO_CNPJ_CADASTRADO("ME007", 400),
	ERRO_IE_CADASTRADO("ME008", 400),
	ERRO_EMAIL_CADASTRADO("ME009", 400),
	ERRO_NENHUM_REGISTRO_ENCONTRADO("ME010", 404),
	ERRO_FILTRO_OBRIGATORIO("ME011", 400),
	ERRO_MATRICULA_VINCULADO("ME012", 400);

	private final String code;

	private final Integer status;

	/**
	 * Construtor da classe.
	 * 
	 * @param code
	 * @param status
	 */
	private PgePessoaMessageCode(final String code, final Integer status) {
		this.code = code;
		this.status = status;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}

	/**
	 * @see java.lang.Enum#toString()
	 */
	@Override
	public String toString() {
		return code;
	}
}
