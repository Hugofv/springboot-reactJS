/*
 * FiltroPessoaTO.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.to;

import io.swagger.annotations.ApiModelProperty;

/**
 * Classe de transferência referente ao filtro de consultas projetadas.
 *
 * @author Squadra Tecnologia
 */
public class FiltroPessoaTO {

	@ApiModelProperty(value = "Código da Pessoa")
	private Long id;

	@ApiModelProperty(value = "Número do CPF da Pessoa Física")
	private String cpf;

	@ApiModelProperty(value = "Número do CNPJ da Pessoa Jurídica")
	private String cnpj;

	@ApiModelProperty(value = "Número do RG da Pessoa Física")
	private String rg;

	@ApiModelProperty(value = "Número da Inscrição Estadual da Pessoa Jurídica")
	private String ie;

	@ApiModelProperty(value = "Nome da Pessoa")
	private String nome;

	@ApiModelProperty(value = "Define a posição do primeiro resultado")
	private Integer firstResult;

	@ApiModelProperty(value = "Define o número máximo de resultados a serem recuperados")
	private Integer maxResults;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the cpf
	 */
	public String getCpf() {
		return cpf;
	}

	/**
	 * @param cpf the cpf to set
	 */
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	/**
	 * @return the cnpj
	 */
	public String getCnpj() {
		return cnpj;
	}

	/**
	 * @param cnpj the cnpj to set
	 */
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	/**
	 * @return the rg
	 */
	public String getRg() {
		return rg;
	}

	/**
	 * @param rg the rg to set
	 */
	public void setRg(String rg) {
		this.rg = rg;
	}

	/**
	 * @return the ie
	 */
	public String getIe() {
		return ie;
	}

	/**
	 * @param ie the ie to set
	 */
	public void setIe(String ie) {
		this.ie = ie;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the firstResult
	 */
	public Integer getFirstResult() {
		return firstResult;
	}

	/**
	 * @param firstResult the firstResult to set
	 */
	public void setFirstResult(Integer firstResult) {
		this.firstResult = firstResult;
	}

	/**
	 * @return the maxResults
	 */
	public Integer getMaxResults() {
		return maxResults;
	}

	/**
	 * @param maxResults the maxResults to set
	 */
	public void setMaxResults(Integer maxResults) {
		this.maxResults = maxResults;
	}

}
