/*
 * ResponseExceptionHandler.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

import br.gov.mt.pge.api.exception.PgeRestResponseExceptionHandler;
import br.gov.mt.pge.comum.exception.MessageCode;

/**
 * Classe handler responsável por interceptar e tratar as exceções de forma
 * amigavel para o client.
 * 
 * @author Squadra Tecnologia
 */
@ControllerAdvice
public class ResponseExceptionHandler extends PgeRestResponseExceptionHandler {

	/**
	 * @see br.gov.mt.pge.api.exception.PgeRestResponseExceptionHandler#getCodeInternalServerError()
	 */
	@Override
	protected MessageCode getCodeInternalServerError() {
		return PgePessoaMessageCode.ERRO_INESPERADO;
	}

}
