/*
 * AuditListener.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.repository.audit;

import java.time.LocalDateTime;

import org.hibernate.envers.RevisionListener;
import org.springframework.security.core.context.SecurityContextHolder;

import br.gov.mt.pge.pessoa.domain.Audit;
import br.gov.mt.pge.pessoa.security.CredentialImpl;

/**
 * Classe de implementação de Listener customizado para a auditoria de dados da
 * aplicação utilizando o Hibernate - Envers.
 * 
 * @author Squadra Tecnologia
 */
public class AuditListener implements RevisionListener {

	/**
	 * @see org.hibernate.envers.RevisionListener#newRevision(java.lang.Object)
	 */
	@Override
	public void newRevision(Object revisionEntity) {
		Audit audit = (Audit) revisionEntity;
		audit.setDataInclusao(LocalDateTime.now());

		CredentialImpl credential = getCredential();
		audit.setIdPessoa(credential.getIdPessoa());
	}

	/**
	 * Retorna a instância de {@link CredentialImpl}.
	 * 
	 * @return
	 */
	private CredentialImpl getCredential() {
		return (CredentialImpl) SecurityContextHolder.getContext().getAuthentication().getCredentials();
	}

}
