/*
 * PessoaJuridicaService.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.service;

import java.time.LocalDateTime;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.gov.mt.pge.comum.exception.BusinessException;
import br.gov.mt.pge.comum.util.CollectionUtil;
import br.gov.mt.pge.comum.util.Util;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.domain.PessoaFisica;
import br.gov.mt.pge.pessoa.domain.PessoaJuridica;
import br.gov.mt.pge.pessoa.exception.PgePessoaMessageCode;
import br.gov.mt.pge.pessoa.repository.PessoaJuridicaRepository;
import br.gov.mt.pge.pessoa.repository.PessoaRepository;

/**
 * Classe de négocio referente a entidade {@link PessoaJuridica}.
 *
 * @author Squadra Tecnologia
 */
@Service
@Transactional(value = TxType.REQUIRED)
public class PessoaJuridicaService {

	@Autowired
	private PessoaJuridicaRepository pessoaJuridicaRepository;

	@Autowired
	private PessoaRepository pessoaRepository;

	@Autowired
	private EmailService emailService;

	/**
	 * Salva a instânica de {@link PessoaFisica} na base de dados conforme os
	 * critérios especificados na aplicação.
	 * 
	 * @param pessoaJuridica
	 * @return
	 */
	public PessoaJuridica salvar(PessoaJuridica pessoaJuridica) {
		validarIe(pessoaJuridica.getIe());
		validarCnpj(pessoaJuridica.getCnpj());
		validarIeCadastrado(pessoaJuridica);
		validarCnpjCadastrado(pessoaJuridica);

		Pessoa pessoa = pessoaJuridica.getPessoa();

		if (!CollectionUtil.isEmpty(pessoa.getEmails())) {
			emailService.validarEmailsCadastrados(pessoa.getEmails());
		}

		if (pessoa.getId() == null) {
			pessoa.setDataInclusao(LocalDateTime.now());
		}
		pessoa = pessoaRepository.save(pessoa);
		pessoaJuridica.setPessoa(pessoa);

		return pessoaJuridicaRepository.save(pessoaJuridica);
	}

	/**
	 * Retorna a instância de {@link PessoaJuridica} conforme o 'idPessoa'
	 * informado.
	 * 
	 * @param idPessoa
	 * @return
	 */
	public PessoaJuridica getPessoaJuridicaByIdPessoa(final Long idPessoa) {
		PessoaJuridica pessoaJuridica = pessoaJuridicaRepository.findByIdPessoaFetch(idPessoa);

		if (pessoaJuridica == null) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_NENHUM_REGISTRO_ENCONTRADO);
		}
		return pessoaJuridica;
	}

	/**
	 * Verifica se o Cnpj informado é válido.
	 * 
	 * @param cnpj
	 */
	public void validarCnpj(final String cnpj) {
		if (!Util.isCnpjValido(cnpj)) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_CNPJ_INVALIDO);
		}
	}

	/**
	 * Verifica se a Inscrição Estadual informada é válida.
	 * 
	 * @param ie
	 */
	public void validarIe(final String ie) {
		if (!Util.isIeValido(ie)) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_IE_INVALIDO);
		}
	}

	/**
	 * Valida se o CNPJ já está cadastrado na base de dados.
	 * 
	 * @param cnpj
	 */
	private void validarCnpjCadastrado(final PessoaJuridica pessoaJuridica) {
		Long count = pessoaJuridicaRepository.countByCnpjAndIdNotIn(pessoaJuridica.getCnpj(), pessoaJuridica.getId());

		if (count > 0) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_CNPJ_CADASTRADO);
		}
	}

	/**
	 * Valida se o Inscrição Estadual já está cadastrado na base de dados.
	 * 
	 * @param ie
	 */
	private void validarIeCadastrado(final PessoaJuridica pessoaJuridica) {
		Long count = pessoaJuridicaRepository.countByIeAndIdNotIn(pessoaJuridica.getIe(), pessoaJuridica.getId());

		if (count > 0) {
			throw new BusinessException(PgePessoaMessageCode.ERRO_IE_CADASTRADO);
		}
	}

}
