/* 	 
 * TipoSituacaoServidor.java  
 * Copyright PGE-MT.  
 * 
 * Este software é confidencial e propriedade da PGE-MT.  
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.  
 * Este arquivo contém informações proprietárias.  
 */
package br.gov.mt.pge.pessoa.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

/**
 * Classe de representação de 'Tipo de Situação do Servidor'.
 * 
 * @author Squadra Tecnologia
 */
@Entity
@Table(name = "TB_TIPO_SITUACAO_SERVIDOR")
@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
public class TipoSituacaoServidor implements Serializable {

	private static final long serialVersionUID = -3804715243878764230L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PK_TIPO_SITUACAO_SERVIDOR", nullable = false)
	private Long id;

	@Column(name = "DS_TIPO_SITUACAO_SERVIDOR", nullable = false, length = 10)
	private String descricao;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TipoSituacaoServidor other = (TipoSituacaoServidor) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}