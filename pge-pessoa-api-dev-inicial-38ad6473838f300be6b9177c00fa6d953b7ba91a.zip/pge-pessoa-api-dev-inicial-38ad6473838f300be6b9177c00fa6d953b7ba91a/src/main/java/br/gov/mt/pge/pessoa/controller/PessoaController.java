/*
 * PessoaController.java  
 * Copyright PGE-MT.  
 * 
 * Este software é confidencial e propriedade da PGE-MT.  
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.  
 * Este arquivo contém informações proprietárias.  
 */
package br.gov.mt.pge.pessoa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.gov.mt.pge.comum.exception.MessageResponse;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.service.PessoaService;
import br.gov.mt.pge.pessoa.to.FiltroPessoaTO;
import br.gov.mt.pge.pessoa.to.PessoaTO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Classe de controle referente a entidade {@link Pessoa}.
 * 
 * @author Squadra Tecnologia
 */
@Api(tags = "Pessoa API")
@RestController
@RequestMapping("${app.api.base}/pessoas")
public class PessoaController extends AbstractController {

	@Autowired
	private PessoaService pessoaService;

	/**
	 * Retorna a lista de {@link PessoaTO} conforme os critérios de pesquisa informado.
	 * 
	 * @param filtroTO
	 * @return
	 */
	@PreAuthorize("isAuthenticated()")
	@ApiOperation(value = "Recupera as informações de Pessoa conforme os critérios de pesquisa.", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiResponses({ 
			@ApiResponse(code = 200, message = "Success", response = PessoaTO.class),
			@ApiResponse(code = 400, message = "Bad Request", response = MessageResponse.class),
			@ApiResponse(code = 404, message = "Not Found", response = MessageResponse.class) })
	@GetMapping(path = "/filtro", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<?> getPessoasByFiltro(
			@ApiParam(value = "Filtro de pesquisa", required = true) @ModelAttribute final FiltroPessoaTO filtroTO) {
		List<PessoaTO> pessoasTO = pessoaService.getPessoasByFiltro(filtroTO);
		return ResponseEntity.ok(pessoasTO);
	}

}