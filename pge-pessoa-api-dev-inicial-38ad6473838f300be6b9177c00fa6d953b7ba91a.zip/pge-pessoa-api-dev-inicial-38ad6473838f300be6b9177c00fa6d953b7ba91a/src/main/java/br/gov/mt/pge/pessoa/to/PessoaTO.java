/*
 * PessoaTO.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.to;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.gov.mt.pge.pessoa.domain.Pessoa;
import io.swagger.annotations.ApiModelProperty;

/**
 * Classe de transferência referente a entidade {@link Pessoa}.
 *
 * @author Squadra Tecnologia
 */
@JsonInclude(Include.NON_NULL)
public class PessoaTO implements Serializable {

	private static final long serialVersionUID = 4357122983653332018L;

	@ApiModelProperty(value = "Código da Pessoa")
	private Long id;

	@ApiModelProperty(value = "Nome da Pessoa")
	private String nome;

	@ApiModelProperty(value = "Cpf da Pessoa Física")
	private String cpf;

	@ApiModelProperty(value = "Cnpj da Pessoa Jurídica")
	private String cnpj;

	@ApiModelProperty(value = "Rg da Pessoa Física")
	private String rg;

	@ApiModelProperty(value = "Inscrição Estadual da Pessoa Jurídica")
	private String ie;

	@ApiModelProperty(value = "Código do Orgão do Servidor")
	private Long idOrgao;

	@ApiModelProperty(value = "Número da matrícula do Servidor")
	private String matricula;

	/**
	 * Construtor da classe.
	 */
	public PessoaTO() {

	}

	/**
	 * Construtor da classe.
	 * 
	 * @param id
	 * @param nome
	 * @param cpf
	 * @param cnpj
	 * @param rg
	 * @param ie
	 * @param idOrgao
	 * @param matricula
	 */
	public PessoaTO(final Long id, final String nome, final String cpf, final String cnpj, final String rg,
			final String ie, final Long idOrgao, final String matricula) {
		this.id = id;
		this.nome = nome;
		this.cpf = cpf;
		this.cnpj = cnpj;
		this.rg = rg;
		this.ie = ie;
		this.idOrgao = idOrgao;
		this.matricula = matricula;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the cpf
	 */
	public String getCpf() {
		return cpf;
	}

	/**
	 * @param cpf the cpf to set
	 */
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	/**
	 * @return the cnpj
	 */
	public String getCnpj() {
		return cnpj;
	}

	/**
	 * @param cnpj the cnpj to set
	 */
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	/**
	 * @return the rg
	 */
	public String getRg() {
		return rg;
	}

	/**
	 * @param rg the rg to set
	 */
	public void setRg(String rg) {
		this.rg = rg;
	}

	/**
	 * @return the ie
	 */
	public String getIe() {
		return ie;
	}

	/**
	 * @param ie the ie to set
	 */
	public void setIe(String ie) {
		this.ie = ie;
	}

	/**
	 * @return the idOrgao
	 */
	public Long getIdOrgao() {
		return idOrgao;
	}

	/**
	 * @param idOrgao the idOrgao to set
	 */
	public void setIdOrgao(Long idOrgao) {
		this.idOrgao = idOrgao;
	}

	/**
	 * @return the matricula
	 */
	public String getMatricula() {
		return matricula;
	}

	/**
	 * @param matricula the matricula to set
	 */
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

}
