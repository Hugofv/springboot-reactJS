package br.gov.mt.pge.pessoa.security;

import br.gov.mt.pge.auth.to.UsuarioTO;
import br.gov.mt.pge.comum.security.Credential;

/**
 * Classe responsável por manter as informações da Credencial do Usuário logado.
 * 
 * @author Squadra Tecnologia
 */
public class CredentialImpl implements Credential {

	private String nome;

	private String login;

	private Long idPessoa;

	private String accessToken;

	/**
	 * Construtor privado para garantir o Singleton.
	 */
	private CredentialImpl() {

	}

	/**
	 * Fábrica de instâncias de {@link CredentialImpl}.
	 * 
	 * @param usuarioTO
	 * @param accessToken
	 * @return
	 */
	public static CredentialImpl newInstance(final UsuarioTO usuarioTO, final String accessToken) {
		CredentialImpl credential = null;

		if (usuarioTO != null) {
			credential = new CredentialImpl();
			credential.setIdPessoa(usuarioTO.getIdPessoa());
			credential.setLogin(usuarioTO.getLogin());
			credential.setNome(usuarioTO.getNome());
			credential.setAccessToken(accessToken);
		}
		return credential;
	}

	/**
	 * @see br.gov.mt.pge.comum.security.Credential#getAccessToken()
	 */
	@Override
	public String getAccessToken() {
		return accessToken;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the login
	 */
	public String getLogin() {
		return login;
	}

	/**
	 * @param login the login to set
	 */
	public void setLogin(String login) {
		this.login = login;
	}

	/**
	 * @return the idPessoa
	 */
	public Long getIdPessoa() {
		return idPessoa;
	}

	/**
	 * @param idPessoa the idPessoa to set
	 */
	public void setIdPessoa(Long idPessoa) {
		this.idPessoa = idPessoa;
	}

	/**
	 * @param accessToken the accessToken to set
	 */
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

}
