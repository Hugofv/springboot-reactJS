/*
 * EmailServiceTest.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.service;

import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import br.gov.mt.pge.comum.exception.BusinessException;
import br.gov.mt.pge.pessoa.domain.Email;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.repository.EmailRepository;

/**
 * Implementação teste referente a classe de négocio {@link EmailService}.
 *
 * @author Squadra Tecnologia
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class EmailServiceTest {

	@Mock
	private EmailRepository emailRepository;

	@InjectMocks
	private EmailService emailService;

	/**
	 * Inicialização da classe de Test.
	 */
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Teste do método responsável por verificar se existe algum e-mail da lista
	 * cadastrado.
	 */
	@Test(expected = BusinessException.class)
	public void validaEmailsCadastradosEncontrado() {
		Set<Email> emails = new HashSet<Email>();
		Email email = getEmailMock();
		emails.add(email);

		when(emailRepository.countByDescricaoAndIdPessoaNotIn(email.getDescricao(), null)).thenReturn(1L);
		emailService.validarEmailsCadastrados(emails);
	}

	/**
	 * Teste do método responsável por verificar se existe algum e-mail da lista
	 * cadastrado.
	 */
	@Test
	public void validaEmailsCadastradosNaoEncontrado() {
		Set<Email> emails = new HashSet<Email>();
		Email email = getEmailMock();
		emails.add(email);

		when(emailRepository.countByDescricaoAndIdPessoaNotIn(email.getDescricao(), null)).thenReturn(0L);
		emailService.validarEmailsCadastrados(emails);
	}

	/**
	 * Retorna a instância Mock de {@link Email}.
	 * 
	 * @return
	 */
	private Email getEmailMock() {
		Email email = new Email();
		email.setPessoa(new Pessoa());
		email.setDescricao("test@teste.com.br");
		return email;
	}
}
