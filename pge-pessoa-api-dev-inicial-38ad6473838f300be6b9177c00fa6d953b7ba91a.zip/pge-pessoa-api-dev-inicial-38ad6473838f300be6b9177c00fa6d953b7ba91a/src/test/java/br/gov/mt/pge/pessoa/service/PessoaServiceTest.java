/*
 * PessoaServiceTest.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.service;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import br.gov.mt.pge.comum.exception.BusinessException;
import br.gov.mt.pge.pessoa.exception.PgePessoaMessageCode;
import br.gov.mt.pge.pessoa.repository.PessoaRepository;
import br.gov.mt.pge.pessoa.to.FiltroPessoaTO;
import br.gov.mt.pge.pessoa.to.PessoaTO;

/**
 * Implementação teste referente a classe de négocio {@link PessoaService}.
 *
 * @author Squadra Tecnologia
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class PessoaServiceTest {

	@Mock
	private PessoaJuridicaService pessoaJuridicaService;

	@Mock
	private PessoaFisicaService pessoaFisicaService;

	@Mock
	private PessoaRepository pessoaRepository;

	@InjectMocks
	private PessoaService pessoaService;

	/**
	 * Inicialização da classe de Test.
	 */
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Teste de método responsável por validar a recuperação da lista de
	 * {@link PessoaTO} por filtro com 'Resultado'.
	 */
	@Test
	public void getPessoaComResultado() {
		FiltroPessoaTO filtroTO = new FiltroPessoaTO();
		filtroTO.setNome("Nome");
		when(pessoaRepository.getPessoasByFiltro(filtroTO)).thenReturn(Arrays.asList(new PessoaTO()));
		pessoaService.getPessoasByFiltro(filtroTO);
	}

	/**
	 * Teste de método responsável por validar a recuperação da lista de
	 * {@link PessoaTO} por filtro sem 'Resultado'.
	 */
	@Test(expected = BusinessException.class)
	public void getPessoaSemResultado() {
		FiltroPessoaTO filtroTO = new FiltroPessoaTO();
		filtroTO.setNome("Nome");
		when(pessoaRepository.getPessoasByFiltro(filtroTO)).thenReturn(Arrays.asList());
		pessoaService.getPessoasByFiltro(filtroTO);
	}

	/**
	 * Teste de método responsável por verificar se os campos do filtro obrigátorio
	 * estão vazios.
	 */
	@Test(expected = BusinessException.class)
	public void validaFiltroComCamposVazios() {
		FiltroPessoaTO filtroTO = new FiltroPessoaTO();
		pessoaService.getPessoasByFiltro(filtroTO);
	}

	/**
	 * Teste de método responsável por verificar se o 'CPF' está preenchido pelo
	 * método filtro obrigátorio.
	 */
	@Test
	public void validaFiltroPossuiCpf() {
		FiltroPessoaTO filtroTO = new FiltroPessoaTO();
		filtroTO.setCpf("51979678626");
		doNothing().when(pessoaFisicaService).validarCpf(filtroTO.getCpf());
		when(pessoaRepository.getPessoasByFiltro(filtroTO)).thenReturn(Arrays.asList(new PessoaTO()));
		pessoaService.getPessoasByFiltro(filtroTO);
	}

	/**
	 * Teste responsável por verificar o cenário de CPF inválido no filtro.
	 */
	@Test(expected = BusinessException.class)
	public void validaFiltroPossuiCpfInvalido() {
		FiltroPessoaTO filtroTO = new FiltroPessoaTO();
		filtroTO.setCpf("11111111111");

		doThrow(new BusinessException(PgePessoaMessageCode.ERRO_CPF_INVALIDO)).when(pessoaFisicaService)
				.validarCpf(filtroTO.getCpf());

		pessoaService.getPessoasByFiltro(filtroTO);
	}

	/**
	 * Teste de método responsável por verificar se o 'RG' está preenchido pelo
	 * método filtro obrigátorio.
	 */
	@Test
	public void validaFiltroPossuiRg() {
		FiltroPessoaTO filtroTO = new FiltroPessoaTO();
		filtroTO.setRg("279826096");
		when(pessoaRepository.getPessoasByFiltro(filtroTO)).thenReturn(Arrays.asList(new PessoaTO()));
		pessoaService.getPessoasByFiltro(filtroTO);
	}

	/**
	 * Teste de método responsável por verificar se o 'CNPJ' está preenchido pelo
	 * método filtro obrigátorio.
	 */
	@Test
	public void validaFiltroPossuiCnpj() {
		FiltroPessoaTO filtroTO = new FiltroPessoaTO();
		filtroTO.setCnpj("34282166000160");
		doNothing().when(pessoaJuridicaService).validarCnpj(filtroTO.getCnpj());
		when(pessoaRepository.getPessoasByFiltro(filtroTO)).thenReturn(Arrays.asList(new PessoaTO()));
		pessoaService.getPessoasByFiltro(filtroTO);
	}

	/**
	 * Teste de método responsável por verificar se o 'CNPJ' está preenchido pelo
	 * método filtro obrigátorio.
	 */
	@Test(expected = BusinessException.class)
	public void validaFiltroPossuiCnpjInvalido() {
		FiltroPessoaTO filtroTO = new FiltroPessoaTO();
		filtroTO.setCnpj("34282166000000");

		doThrow(new BusinessException(PgePessoaMessageCode.ERRO_CNPJ_INVALIDO)).when(pessoaJuridicaService)
				.validarCnpj(filtroTO.getCnpj());

		pessoaService.getPessoasByFiltro(filtroTO);
	}

	/**
	 * Teste de método responsável por verificar se o 'IE' está preenchido pelo
	 * método filtro obrigátorio.
	 */
	@Test
	public void validaFiltroPossuiIe() {
		FiltroPessoaTO filtroTO = new FiltroPessoaTO();
		filtroTO.setIe("56390513984");
		doNothing().when(pessoaJuridicaService).validarIe(filtroTO.getIe());
		when(pessoaRepository.getPessoasByFiltro(filtroTO)).thenReturn(Arrays.asList(new PessoaTO()));
		pessoaService.getPessoasByFiltro(filtroTO);
	}

	/**
	 * Teste de método para verificar o cenário onde o IE informado é inválido.
	 */
	@Test(expected = BusinessException.class)
	public void validaFiltroPossuiIeInvalido() {
		FiltroPessoaTO filtroTO = new FiltroPessoaTO();
		filtroTO.setIe("563905139");

		doThrow(new BusinessException(PgePessoaMessageCode.ERRO_IE_INVALIDO)).when(pessoaJuridicaService)
				.validarIe(filtroTO.getIe());

		pessoaService.getPessoasByFiltro(filtroTO);
	}

	/**
	 * Teste de método responsável por verificar se o 'Id' está preenchido pelo
	 * método filtro obrigátorio.
	 */
	@Test
	public void validaFiltroPossuiId() {
		FiltroPessoaTO filtroTO = new FiltroPessoaTO();
		filtroTO.setId(1L);
		when(pessoaRepository.getPessoasByFiltro(filtroTO)).thenReturn(Arrays.asList(new PessoaTO()));
		pessoaService.getPessoasByFiltro(filtroTO);
	}

}
