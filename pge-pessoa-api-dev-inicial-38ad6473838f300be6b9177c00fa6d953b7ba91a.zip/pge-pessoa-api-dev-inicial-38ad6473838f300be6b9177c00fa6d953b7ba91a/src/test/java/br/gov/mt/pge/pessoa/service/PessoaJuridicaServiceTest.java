/*
 * PessoaJuridicaServiceTest.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.HashSet;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import br.gov.mt.pge.comum.exception.BusinessException;
import br.gov.mt.pge.pessoa.domain.Email;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.domain.PessoaJuridica;
import br.gov.mt.pge.pessoa.exception.PgePessoaMessageCode;
import br.gov.mt.pge.pessoa.repository.PessoaJuridicaRepository;
import br.gov.mt.pge.pessoa.repository.PessoaRepository;

/**
 * Implementação teste referente a classe de négocio
 * {@link PessoaJuridicaService}.
 *
 * @author Squadra Tecnologia
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class PessoaJuridicaServiceTest {

	@Mock
	private EmailService emailService;

	@Mock
	private PessoaRepository pessoaRepository;

	@Mock
	private PessoaJuridicaRepository pessoaJuridicaRepository;

	@InjectMocks
	private PessoaJuridicaService pessoaJuridicaService;

	/**
	 * Inicialização da classe de Test.
	 */
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Teste do método de salvar Pessoa Jurídica considerando um cenário de sucesso.
	 */
	@Test
	public void salvaPessoaJuridicaInclusao() {
		PessoaJuridica pessoaJuridica = this.getPessoaJuridicaMock();
		when(pessoaJuridicaRepository.countByCnpjAndIdNotIn(pessoaJuridica.getCnpj(), null)).thenReturn(0L);
		when(pessoaJuridicaRepository.countByIeAndIdNotIn(pessoaJuridica.getIe(), null)).thenReturn(0L);
		when(pessoaRepository.save(pessoaJuridica.getPessoa())).thenReturn(pessoaJuridica.getPessoa());
		when(pessoaJuridicaRepository.save(pessoaJuridica)).thenReturn(pessoaJuridica);
		PessoaJuridica result = pessoaJuridicaService.salvar(pessoaJuridica);
		assertNotNull(result);
	}

	/**
	 * Teste do método de salvar Pessoa Jurídica considerando um cenário de sucesso.
	 */
	@Test
	public void salvaPessoaJuridicaAlteracao() {
		PessoaJuridica pessoaJuridica = this.getPessoaJuridicaMock();
		pessoaJuridica.setId(1L);
		when(pessoaJuridicaRepository.countByCnpjAndIdNotIn(pessoaJuridica.getCnpj(), 1L)).thenReturn(0L);
		when(pessoaJuridicaRepository.countByIeAndIdNotIn(pessoaJuridica.getIe(), 1L)).thenReturn(0L);
		when(pessoaRepository.save(pessoaJuridica.getPessoa())).thenReturn(pessoaJuridica.getPessoa());
		when(pessoaJuridicaRepository.save(pessoaJuridica)).thenReturn(pessoaJuridica);
		PessoaJuridica result = pessoaJuridicaService.salvar(pessoaJuridica);
		assertNotNull(result);
	}

	/**
	 * Teste do método de salvar Pessoa Jurídica considerando um 'CNPJ' inválido.
	 */
	@Test(expected = BusinessException.class)
	public void salvaPessoaJuridicaCnpjInvalido() {
		PessoaJuridica pessoaJuridica = this.getPessoaJuridicaMock();
		when(pessoaJuridicaRepository.countByCnpjAndIdNotIn(pessoaJuridica.getCnpj(), null)).thenReturn(0L);
		when(pessoaJuridicaRepository.countByIeAndIdNotIn(pessoaJuridica.getIe(), null)).thenReturn(0L);
		pessoaJuridica.setCnpj("3428216600011");
		pessoaJuridicaService.salvar(pessoaJuridica);
	}

	/**
	 * Teste do método de salvar Pessoa Jurídica considerando um "IE" válido.
	 */
	@Test(expected = BusinessException.class)
	public void salvaPessoaJuridicaIeInvalido() {
		PessoaJuridica pessoaJuridica = this.getPessoaJuridicaMock();
		when(pessoaJuridicaRepository.countByCnpjAndIdNotIn(pessoaJuridica.getCnpj(), null)).thenReturn(0L);
		when(pessoaJuridicaRepository.countByIeAndIdNotIn(pessoaJuridica.getIe(), null)).thenReturn(0L);
		pessoaJuridica.setIe("1");
		pessoaJuridicaService.salvar(pessoaJuridica);
	}

	/**
	 * Teste do método de salvar Pessoa Jurídica considerando um "CNPJ" que possui
	 * cadastrado na base de dados.
	 */
	@Test(expected = BusinessException.class)
	public void salvaPessoaJuridicaCnpjJaCadastrado() {
		PessoaJuridica pessoaJuridica = this.getPessoaJuridicaMock();
		when(pessoaJuridicaRepository.countByCnpjAndIdNotIn(pessoaJuridica.getCnpj(), null)).thenReturn(1L);
		when(pessoaJuridicaRepository.countByIeAndIdNotIn(pessoaJuridica.getIe(), null)).thenReturn(0L);
		pessoaJuridicaService.salvar(pessoaJuridica);
	}

	/**
	 * Teste do método de salvar Pessoa Jurídica considerando um "IE" que possui
	 * cadastrado na base de dados.
	 */
	@Test(expected = BusinessException.class)
	public void salvaPessoaJuridicaIeJaCadastrado() {
		PessoaJuridica pessoaJuridica = this.getPessoaJuridicaMock();
		when(pessoaJuridicaRepository.countByCnpjAndIdNotIn(pessoaJuridica.getCnpj(), null)).thenReturn(0L);
		when(pessoaJuridicaRepository.countByIeAndIdNotIn(pessoaJuridica.getIe(), null)).thenReturn(1L);
		pessoaJuridicaService.salvar(pessoaJuridica);
	}

	/**
	 * Teste do método de salvar Pessoa Jurídica considerando um "Email" que possui
	 * cadastrado na base de dados.
	 */
	@Test(expected = BusinessException.class)
	public void salvaPessoaJuridicaEmailJaCadastrado() {
		PessoaJuridica pessoaJuridica = this.getPessoaJuridicaMock();

		Email email = new Email();
		pessoaJuridica.getPessoa().setEmails(new HashSet<Email>());
		pessoaJuridica.getPessoa().getEmails().add(email);

		doThrow(new BusinessException(PgePessoaMessageCode.ERRO_EMAIL_CADASTRADO)).when(emailService)
				.validarEmailsCadastrados(pessoaJuridica.getPessoa().getEmails());

		when(pessoaJuridicaRepository.countByCnpjAndIdNotIn(pessoaJuridica.getCnpj(), null)).thenReturn(0L);
		when(pessoaJuridicaRepository.countByIeAndIdNotIn(pessoaJuridica.getIe(), null)).thenReturn(0L);
		pessoaJuridicaService.salvar(pessoaJuridica);
	}

	/**
	 * Teste do método de salvar Pessoa Jurídica considerando um "Email".
	 */
	@Test
	public void salvaPessoaJuridicaComEmail() {
		PessoaJuridica pessoaJuridica = this.getPessoaJuridicaMock();

		Email email = new Email();
		pessoaJuridica.getPessoa().setEmails(new HashSet<Email>());
		pessoaJuridica.getPessoa().getEmails().add(email);

		doNothing().when(emailService).validarEmailsCadastrados(pessoaJuridica.getPessoa().getEmails());

		when(pessoaJuridicaRepository.countByCnpjAndIdNotIn(pessoaJuridica.getCnpj(), null)).thenReturn(0L);
		when(pessoaJuridicaRepository.countByIeAndIdNotIn(pessoaJuridica.getIe(), null)).thenReturn(0L);
		pessoaJuridicaService.salvar(pessoaJuridica);
	}

	/**
	 * Teste do método de recuperação dos dados da Pessoa Jurídica sem resultado.
	 */
	@Test(expected = BusinessException.class)
	public void getPessoaFisicaByIdPessoaSemResultado() {
		when(pessoaJuridicaRepository.findByIdPessoaFetch(1L)).thenReturn(null);
		pessoaJuridicaService.getPessoaJuridicaByIdPessoa(1L);
	}

	/**
	 * Teste do método de recuperação dos dados da Pessoa Jurídica com resultado.
	 */
	@Test
	public void getPessoaFisicaByIdPessoaComResultado() {
		when(pessoaJuridicaRepository.findByIdPessoaFetch(1L)).thenReturn(this.getPessoaJuridicaMock());
		PessoaJuridica pessoaJuridica = pessoaJuridicaService.getPessoaJuridicaByIdPessoa(1L);
		assertNotNull(pessoaJuridica);
	}

	/**
	 * Teste do método responsável por verificar se o 'CNPJ' é válido.
	 */
	@Test
	public void validaCnpjValido() {
		PessoaJuridica pessoaJuridica = new PessoaJuridica();
		pessoaJuridicaService.validarCnpj(pessoaJuridica.getCnpj());
	}

	/**
	 * Teste do método responsável por verificar se o 'CNPJ' é inválido.
	 */
	@Test(expected = BusinessException.class)
	public void validaCnpjInvalido() {
		PessoaJuridica pessoaJuridica = new PessoaJuridica();
		pessoaJuridica.setCnpj("34282166000161");
		pessoaJuridicaService.validarCnpj(pessoaJuridica.getCnpj());
	}

	/**
	 * Retorna a instância mock de {@link PessoaJuridica}.
	 * 
	 * @return
	 */
	private PessoaJuridica getPessoaJuridicaMock() {
		PessoaJuridica pessoaJuridica = new PessoaJuridica();
		pessoaJuridica.setNomeFantasia("Exemplo");
		pessoaJuridica.setCnpj("34282166000160");
		pessoaJuridica.setIe("87153068707");

		Pessoa pessoa = new Pessoa();
		pessoa.setNome("Nome Pessoa");
		pessoaJuridica.setPessoa(pessoa);

		return pessoaJuridica;
	}
}
