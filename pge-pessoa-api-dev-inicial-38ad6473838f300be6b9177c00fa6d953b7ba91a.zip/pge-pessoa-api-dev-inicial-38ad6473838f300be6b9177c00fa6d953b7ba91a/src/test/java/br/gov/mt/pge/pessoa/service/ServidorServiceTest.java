/*
 * ServidorServiceTest.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import br.gov.mt.pge.comum.exception.BusinessException;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.domain.PessoaFisica;
import br.gov.mt.pge.pessoa.domain.Servidor;
import br.gov.mt.pge.pessoa.domain.TipoSituacaoServidor;
import br.gov.mt.pge.pessoa.repository.PessoaFisicaRepository;
import br.gov.mt.pge.pessoa.repository.ServidorRepository;

/**
 * Implementação teste referente a classe de négocio {@link ServidorService}.
 *
 * @author Squadra Tecnologia
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class ServidorServiceTest {
	
	@Mock
	private ServidorRepository servidorRepository;
	
	@Mock
	private PessoaFisicaRepository pessoaFisicaRepository;
	
	@Mock
	private PessoaFisicaService pessoaFisicaService;
	
	@InjectMocks
	private ServidorService servidorService;

	/**
	 * Inicialização da classe de Test.
	 */
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	/**
	 * Teste do método de salvar Servidor considerando um cenário de sucesso.
	 */
	@Test
	public void salvaServidorInclusao() {
		Servidor servidor = this.getServidorMock();
		when(pessoaFisicaRepository.countByCpfAndIdNotIn(servidor.getPessoaFisica().getCpf(), null)).thenReturn(0L);
		when(pessoaFisicaService.salvar(servidor.getPessoaFisica())).thenReturn(servidor.getPessoaFisica());
		when(servidorRepository.save(servidor)).thenReturn(servidor);
		Servidor result = servidorService.salvar(servidor);
		assertNotNull(result);
	}
	
	/**
	 * Teste de método de alterar Servidor considerando um cenário de sucesso.
	 */
	@Test
	public void salvaServidorAlteracao() {
		Servidor servidor = this.getServidorMock();
		servidor.setId(1L);
		
		when(pessoaFisicaRepository.countByCpfAndIdNotIn(servidor.getPessoaFisica().getCpf(), 1L)).thenReturn(0L);
		when(pessoaFisicaService.salvar(servidor.getPessoaFisica())).thenReturn(servidor.getPessoaFisica());
		when(servidorRepository.save(servidor)).thenReturn(servidor);
		Servidor result = servidorService.salvar(servidor);
		assertNotNull(result);
	}
	
	/**
	 * Teste do método de recuperação dos dados da Servidor sem resultado.
	 */
	@Test(expected = BusinessException.class)
	public void getServidorByIdServidorSemResultado() {
		when(servidorRepository.findByIdPessoaFetch(1L)).thenReturn(null);
		servidorService.getServidorByIdPessoa(1L);
	}
	
	/**
	 * Teste de método de recuperação dos dados do Servidor com resultado.
	 */
	@Test
	public void getServidorByIdServidorComResultado() {
		when(servidorRepository.findByIdPessoaFetch(1L)).thenReturn(this.getServidorMock());
		Servidor servidor = servidorService.getServidorByIdPessoa(1L);
		assertNotNull(servidor);
	}
	
	@Test(expected = BusinessException.class)
	public void salvaServidorMatriculaCadastrado() {
		Servidor servidor = this.getServidorMock();
		when(servidorRepository.countByMatriculaAndIdNotIn(servidor.getMatricula(), null)).thenReturn(1L);
		servidorService.salvar(servidor);
	}
	
	/**
	 * Retorna a instância mock de {@link Servidor}.
	 * 
	 * @return
	 */
	public Servidor getServidorMock() {
		TipoSituacaoServidor tipoSituacaoServidor = new TipoSituacaoServidor();
		tipoSituacaoServidor.setDescricao("Ativo");
		
		Servidor servidor = new Servidor();
		servidor.setSituacao(tipoSituacaoServidor);
		servidor.setMatricula("1234567");
		servidor.setIdOrgao(1L);
		
		PessoaFisica pessoaFisica = new PessoaFisica();
		pessoaFisica.setCpf("51979678626");
		servidor.setPessoaFisica(pessoaFisica);
		
		Pessoa pessoa = new Pessoa();
		pessoa.setNome("Nome Pessoa");
		pessoaFisica.setPessoa(pessoa);
		
		return servidor;
	}

}
