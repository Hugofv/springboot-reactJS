/*
 * PessoaFisicaServiceTest.java
 * Copyright (c) PGE-MT.
 *
 * Este software é confidencial e propriedade da PGE-MT.
 * Não é permitida sua distribuição ou divulgação do seu conteúdo sem expressa autorização da PGE-MT.
 * Este arquivo contém informações proprietárias.
 */
package br.gov.mt.pge.pessoa.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.HashSet;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import br.gov.mt.pge.comum.exception.BusinessException;
import br.gov.mt.pge.pessoa.domain.Email;
import br.gov.mt.pge.pessoa.domain.Pessoa;
import br.gov.mt.pge.pessoa.domain.PessoaFisica;
import br.gov.mt.pge.pessoa.exception.PgePessoaMessageCode;
import br.gov.mt.pge.pessoa.repository.PessoaFisicaRepository;
import br.gov.mt.pge.pessoa.repository.PessoaRepository;

/**
 * Implementação teste referente a classe de négocio
 * {@link PessoaFisicaService}.
 *
 * @author Squadra Tecnologia
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class PessoaFisicaServiceTest {

	@Mock
	private PessoaFisicaRepository pessoaFisicaRepository;

	@Mock
	private PessoaRepository pessoaRepository;

	@Mock
	private EmailService emailService;

	@InjectMocks
	private PessoaFisicaService pessoaFisicaService;

	/**
	 * Inicialização da classe de Test.
	 */
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Teste do método de salvar Pessoa Física considerando um cenário de sucesso.
	 */
	@Test
	public void salvaPessoaFisicaInclusao() {
		PessoaFisica pessoaFisica = this.getPessoaFisicaMock();
		when(pessoaFisicaRepository.countByCpfAndIdNotIn(pessoaFisica.getCpf(), null)).thenReturn(0L);
		when(pessoaRepository.save(pessoaFisica.getPessoa())).thenReturn(pessoaFisica.getPessoa());
		when(pessoaFisicaRepository.save(pessoaFisica)).thenReturn(pessoaFisica);
		PessoaFisica result = pessoaFisicaService.salvar(pessoaFisica);
		assertNotNull(result);
	}

	/**
	 * Teste do método de salvar Pessoa Física considerando um cenário de sucesso.
	 */
	@Test
	public void salvaPessoaFisicaAlteracao() {
		PessoaFisica pessoaFisica = this.getPessoaFisicaMock();
		pessoaFisica.setId(1L);

		when(pessoaFisicaRepository.countByCpfAndIdNotIn(pessoaFisica.getCpf(), 1L)).thenReturn(0L);
		when(pessoaRepository.save(pessoaFisica.getPessoa())).thenReturn(pessoaFisica.getPessoa());
		when(pessoaFisicaRepository.save(pessoaFisica)).thenReturn(pessoaFisica);
		PessoaFisica result = pessoaFisicaService.salvar(pessoaFisica);
		assertNotNull(result);
	}

	/**
	 * Teste do método de salvar Pessoa Física considerando um 'CPF' inválido.
	 */
	@Test(expected = BusinessException.class)
	public void salvaPessoaFisicaCpfInvalido() {
		PessoaFisica pessoaFisica = this.getPessoaFisicaMock();
		when(pessoaFisicaRepository.countByCpfAndIdNotIn(pessoaFisica.getCpf(), null)).thenReturn(0L);
		pessoaFisica.setCpf("51979678611");
		pessoaFisicaService.salvar(pessoaFisica);
	}

	/**
	 * Teste do método de salvar Pessoa Física considerando um "CPF" que possui
	 * cadastrado na base de dados.
	 */
	@Test(expected = BusinessException.class)
	public void salvaPessoaFisicaCpfCadastrado() {
		PessoaFisica pessoaFisica = this.getPessoaFisicaMock();
		when(pessoaFisicaRepository.countByCpfAndIdNotIn(pessoaFisica.getCpf(), null)).thenReturn(1L);
		pessoaFisicaService.salvar(pessoaFisica);
	}

	/**
	 * Teste do método de salvar Pessoa Física considerando um "Email" que possui
	 * cadastrado na base de dados.
	 */
	@Test(expected = BusinessException.class)
	public void salvaPessoaFisicaEmailJaCadastrado() {
		PessoaFisica pessoaFisica = this.getPessoaFisicaMock();

		Email email = new Email();
		pessoaFisica.getPessoa().setEmails(new HashSet<Email>());
		pessoaFisica.getPessoa().getEmails().add(email);

		doThrow(new BusinessException(PgePessoaMessageCode.ERRO_EMAIL_CADASTRADO)).when(emailService)
				.validarEmailsCadastrados(pessoaFisica.getPessoa().getEmails());

		when(pessoaFisicaRepository.countByCpfAndIdNotIn(pessoaFisica.getCpf(), null)).thenReturn(0L);
		pessoaFisicaService.salvar(pessoaFisica);
	}

	/**
	 * Teste do método de salvar Pessoa Física considerando um "Email".
	 */
	@Test
	public void salvaPessoaFisicaComEmail() {
		PessoaFisica pessoaFisica = this.getPessoaFisicaMock();

		Email email = new Email();
		pessoaFisica.getPessoa().setEmails(new HashSet<Email>());
		pessoaFisica.getPessoa().getEmails().add(email);

		doNothing().when(emailService).validarEmailsCadastrados(pessoaFisica.getPessoa().getEmails());
		when(pessoaFisicaRepository.countByCpfAndIdNotIn(pessoaFisica.getCpf(), null)).thenReturn(0L);
		pessoaFisicaService.salvar(pessoaFisica);
	}

	/**
	 * Teste do método de recuperação dos dados da Pessoa Física sem resultado.
	 */
	@Test(expected = BusinessException.class)
	public void getPessoaFisicaByIdPessoaSemResultado() {
		when(pessoaFisicaRepository.findByIdPessoaFetch(1L)).thenReturn(null);
		pessoaFisicaService.getPessoaFisicaByIdPessoa(1L);
	}

	/**
	 * Teste do método de recuperação dos dados da Pessoa Física com resultado.
	 */
	@Test
	public void getPessoaFisicaByIdPessoaComResultado() {
		when(pessoaFisicaRepository.findByIdPessoaFetch(1L)).thenReturn(this.getPessoaFisicaMock());
		PessoaFisica pessoaFisica = pessoaFisicaService.getPessoaFisicaByIdPessoa(1L);
		assertNotNull(pessoaFisica);
	}

	/**
	 * Teste do método responsável por verificar se o 'CPF' é válido.
	 */
	@Test
	public void validaCpfValido() {
		PessoaFisica pessoaFisica = this.getPessoaFisicaMock();
		pessoaFisicaService.validarCpf(pessoaFisica.getCpf());
	}

	/**
	 * Teste de método responsável por verificar se o 'CPF' é inválido.
	 */
	@Test(expected = BusinessException.class)
	public void validaCpfInvalido() {
		PessoaFisica pessoaFisica = this.getPessoaFisicaMock();
		pessoaFisica.setCpf("51979678611");
		pessoaFisicaService.validarCpf(pessoaFisica.getCpf());
	}

	/**
	 * Retorna a instância mock de {@link PessoaFisica}.
	 * 
	 * @return
	 */
	public PessoaFisica getPessoaFisicaMock() {
		PessoaFisica pessoaFisica = new PessoaFisica();
		pessoaFisica.setCpf("51979678626");

		Pessoa pessoa = new Pessoa();
		pessoa.setNome("Nome Pessoa");
		pessoaFisica.setPessoa(pessoa);

		return pessoaFisica;
	}

}
